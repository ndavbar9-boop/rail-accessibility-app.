import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Animated, Easing, FlatList, KeyboardAvoidingView, Linking, Platform, SafeAreaView, ScrollView, StatusBar, StyleSheet, Switch, Text, TextInput, TouchableOpacity, Vibration, View } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons, FontAwesome5 } from '@expo/vector-icons';

/* Reminders: implemented without external packages (no expo-notifications) so it works in any Expo Go environment with no extra install needed. While the app is open, a timer checks every 20 seconds whether an appointment is approaching, and shows an alert + vibration. */

/* =========================================================
   CONFIG
========================================================= */

const STORAGE_KEY = '@rail_accessibility_app_v3';
const ADMIN_USERNAME = '10203040';
/* This is only a temporary placeholder, not a real password - it must be changed on first login (via Settings) */
const DEFAULT_ADMIN_PASSWORD = 'שנה_אותי_עכשיו';

const MAX_LOGIN_ATTEMPTS = 5;
const LOGIN_LOCKOUT_MS = 5 * 60 * 1000;
const INACTIVITY_TIMEOUT_MS = 10 * 60 * 1000;
const ACTIVITY_LOG_LIMIT = 200;

/* Replace this with the link to the Israel Railways schedule site */
const TRAIN_SCHEDULE_URL = 'https://www.rail.co.il/';

const FALLBACK_STATIONS = [
  'אופקים', 'אחיהוד', 'אשדוד עד הלום', 'אשקלון', 'באר יעקב', 'באר שבע מרכז',
  'באר שבע צפון', 'בית יהושע', 'בית שאן דויד לוי', 'בית שמש', 'בני ברק',
  'בנימינה', 'בת ים אלי כהן', 'בת ים הקוממיות', 'בת ים יוספטל', 'דימונה',
  'הוד השרון סוקולוב', 'הרצליה', 'חדרה מערב', 'חולון וולפסון', 'חוצות המפרץ',
  'חיפה בת גלים', 'חיפה חוף הכרמל', 'חיפה מרכז השמונה', 'יבנה מזרח',
  'יבנה מערב', 'יוקנעם כפר יהושע', 'ירושלים יצחק נבון', 'כפר חבד',
  'כפר סבא נורדאו', 'כרמיאל', 'להבים רהט', 'לוד', 'לוד גני אביב',
  'מגדל העמק כפר ברוך', 'מודיעין מרכז', 'מזכרת בתיה', 'מרכזית המפרץ',
  'נהריה', 'נתבג', 'נתיבות', 'נתניה', 'נתניה ספיר', 'עכו', 'עפולה', 'עתלית',
  'פאתי מודיעין', 'פתח תקווה סגולה', 'פתח תקווה קריית אריה', 'צומת חולון',
  'קיסריה פרדס חנה', 'קריית גת', 'קריית חיים', 'קריית מלאכי יואב',
  'ראש העין צפון', 'ראשון לציון הראשונים', 'ראשון לציון משה דיין', 'רחובות',
  'רמלה', 'רעננה דרום', 'רעננה מערב', 'שדרות', 'תל אביב אוניברסיטה',
  'תל אביב ההגנה', 'תל אביב השלום', 'תל אביב סבידור מרכז',
];

const DISABILITY_TYPES = ['לקוי ראייה', 'הליכון - קביים - מוגבל בהליכה', 'כיסא גלגלים - קולנועית'];
const HELP_TYPES = ['מעלון', 'עזרה ידנית בלבד', 'כסא תחנה (ללא מעלון)', 'כסא תחנה כולל מעלון'];
const BOARD_TYPES = ['להוריד', 'להעלות', 'להוריד ולהעלות'];
const CAR_LOCATIONS = ['אמצע', 'דרומי'];
const PLATFORM_NUMBERS = ['1', '2', '3', '4', '5', '6', '7', '8'];
const CARS_NUMBERS = Array.from({ length: 10 }, (_, i) => String(i + 5)); // 5–14
const REMINDER_MINUTES_BEFORE = 15;
const ALERT_OPTIONS = [
  'תקין (ללא התראה)', 'מעלית רציף 1 לא תקינה', 'מעלית רציף 2 לא תקינה',
  '2 מעליות לא תקינות (תחנה לא נגישה)', 'מעלון דרומי רציף אחד לא תקין',
  'מעלון אמצע רציף אחד לא תקין', 'מעלון דרומי רציף 2 לא תקין', 'מעלון אמצע רציף 2 לא תקין',
];

/* =========================================================
   HELPERS
========================================================= */

const createEmptyAppointment = (homeStation = 'תל אביב סבידור מרכז') => ({
  isUnscheduled: false,
  passengerName: '',
  passengerPhone: '',
  disabilityType: 'כיסא גלגלים - קולנועית',
  helpType: 'מעלון',
  fromStation: homeStation,
  toStation: '',
  boardType: 'להוריד ולהעלות',
  boardTrainNum: '',
  boardCarsNum: '6',
  boardDate: todayISODate(),
  boardTime: '',
  boardPlatform: '',
  boardCarLocation: 'אמצע',
  secondaryTrainNum: '',
  secondaryCarsNum: '6',
  secondaryDate: todayISODate(),
  secondaryTime: '',
  secondaryPlatform: '',
  secondaryCarLocation: 'אמצע',
  transferEnabled: false,
  transferFromStation: '',
  transferToStation: '',
  stewardNotes: '',
});

const createDefaultSettings = () => ({
  defaultHomeStation: 'תל אביב סבידור מרכז',
  pushAlerts: true,
  soundAlerts: true,
  autoDarkMode: true,
  emergencyPhone: '03-5774000',
  managerPhone: '0500000000',
});

const createDefaultStewards = () => [
  { username: '10203040', password: DEFAULT_ADMIN_PASSWORD, name: 'מנהל ראשי', isAdmin: true },
  { username: '2030', password: '1234', name: 'דייל שטח', isAdmin: false },
];

const normalizeStations = (stations) => {
  const source = Array.isArray(stations) ? stations : FALLBACK_STATIONS;
  return [...new Set(source.map((x) => String(x || '').trim()).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b, 'he'));
};

const isValidTime = (value) => {
  if (!/^\d{2}:\d{2}$/.test(value || '')) return false;
  const [h, m] = value.split(':').map(Number);
  return h >= 0 && h <= 23 && m >= 0 && m <= 59;
};

const isValidPhone = (value) => String(value || '').replace(/\D/g, '').length >= 9;

const getMinutes = (value) => {
  if (!isValidTime(value)) return null;
  const [h, m] = value.split(':').map(Number);
  return h * 60 + m;
};

const formatDate = (value) => {
  if (!value) return '';
  try { return new Date(value).toLocaleString('he-IL'); } catch { return ''; }
};

const todayISODate = () => {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const isValidDate = (value) => /^\d{4}-\d{2}-\d{2}$/.test(value || '');

const formatDateShort = (value) => {
  if (!isValidDate(value)) return '';
  const [y, m, d] = value.split('-');
  return `${d}/${m}/${y}`;
};

/* Combine a YYYY-MM-DD date and HH:MM time into a JS Date */
const combineDateAndTime = (dateValue, timeValue) => {
  if (!isValidDate(dateValue) || !isValidTime(timeValue)) return null;
  const [y, m, d] = dateValue.split('-').map(Number);
  const [h, min] = timeValue.split(':').map(Number);
  return new Date(y, m - 1, d, h, min, 0, 0);
};

const normalizePhoneForWhatsApp = (phone) => {
  const digits = String(phone || '').replace(/\D/g, '');
  if (digits.startsWith('0')) return `972${digits.slice(1)}`;
  if (digits.startsWith('972')) return digits;
  return digits;
};

const maskPhone = (phone) => {
  const digits = String(phone || '').replace(/\D/g, '');
  if (digits.length < 6) return phone || '';
  const visibleStart = digits.slice(0, 3);
  const visibleEnd = digits.slice(-2);
  const masked = '•'.repeat(digits.length - 5);
  return `${visibleStart}${masked}${visibleEnd}`;
};

/* Requires 6+ chars with at least one letter and one digit */
const validatePasswordStrength = (pass) => {
  const value = String(pass || '');
  if (value.length < 6) return 'הסיסמה חייבת לכלול לפחות 6 תווים.';
  if (!/[a-zA-Zא-ת]/.test(value)) return 'הסיסמה חייבת לכלול לפחות אות אחת.';
  if (!/\d/.test(value)) return 'הסיסמה חייבת לכלול לפחות ספרה אחת.';
  return null;
};

/* =========================================================
   MAIN APP
========================================================= */

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [ready, setReady] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [currentSteward, setCurrentSteward] = useState('');
  const [currentUsername, setCurrentUsername] = useState('');
  const [loginAttempts, setLoginAttempts] = useState({});
  const [lockouts, setLockouts] = useState({});
  const [activityLog, setActivityLog] = useState([]);
  const lastActivityRef = useRef(Date.now());
  const [isAdmin, setIsAdmin] = useState(false);

  const [stationsList, setStationsList] = useState(normalizeStations(FALLBACK_STATIONS));
  const [stewardsList, setStewardsList] = useState(createDefaultStewards());
  const [appointments, setAppointments] = useState([]);
  const [settings, setSettings] = useState(createDefaultSettings());
  const [activeAlertMessage, setActiveAlertMessage] = useState('');

  const [activeTab, setActiveTab] = useState('active');
  const [dark, setDark] = useState(false);
  const [search, setSearch] = useState('');

  const [stationModal, setStationModal] = useState(false);
  const [stationField, setStationField] = useState(null);
  const [stationTarget, setStationTarget] = useState('new');
  const [stationSearch, setStationSearch] = useState('');

  const [timeModal, setTimeModal] = useState(false);
  const [timeField, setTimeField] = useState('');
  const [timeTarget, setTimeTarget] = useState('new');

  const [platformModal, setPlatformModal] = useState(false);
  const [platformField, setPlatformField] = useState('');
  const [platformTarget, setPlatformTarget] = useState('new');

  const [carsModal, setCarsModal] = useState(false);
  const [carsField, setCarsField] = useState('');
  const [carsTarget, setCarsTarget] = useState('new');

  const [isOffline, setIsOffline] = useState(false);

  const [settingsModal, setSettingsModal] = useState(false);
  const [editModal, setEditModal] = useState(false);
  const [editingId, setEditingId] = useState(null);

  const [newApp, setNewApp] = useState(createEmptyAppointment());
  const [editApp, setEditApp] = useState(createEmptyAppointment());

  const [toast, setToast] = useState(null);
  const [showSystemAlertModal, setShowSystemAlertModal] = useState(false);
  const [saving, setSaving] = useState(false);

  const toastTimerRef = useRef(null);

  /* LOAD */
  useEffect(() => { loadStorage(); }, []);

  const loadStorage = async () => {
    try {
      const raw = await AsyncStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        if (Array.isArray(data.appointments)) setAppointments(data.appointments);
        if (data.settings) setSettings({ ...createDefaultSettings(), ...data.settings });
        if (Array.isArray(data.stewardsList)) {
          // Merge in any default accounts (e.g. newly added admins) that are missing
          // from previously-saved data, without touching existing accounts/passwords.
          const existingUsernames = new Set(data.stewardsList.map((s) => s.username));
          const missingDefaults = createDefaultStewards().filter((s) => !existingUsernames.has(s.username));
          setStewardsList([...data.stewardsList, ...missingDefaults]);
        }
        if (Array.isArray(data.stationsList) && data.stationsList.length) setStationsList(normalizeStations(data.stationsList));
        if (Array.isArray(data.activityLog)) setActivityLog(data.activityLog);
        if (typeof data.activeAlertMessage === 'string') setActiveAlertMessage(data.activeAlertMessage);
        if (data.dark !== undefined) setDark(Boolean(data.dark));
        if (data.currentSteward) {
          setCurrentSteward(data.currentSteward);
          setCurrentUsername(data.currentUsername || '');
          setIsAdmin(Boolean(data.isAdmin));
          setIsLoggedIn(true);
        }
      }
    } catch (error) {
      console.log('Storage load error:', error);
    } finally {
      setReady(true);
    }
  };

  /* SAVE */
  useEffect(() => {
    if (!ready) return;
    saveStorage();
  }, [ready, appointments, settings, stewardsList, stationsList, activeAlertMessage, dark, currentSteward, currentUsername, isAdmin, activityLog]);

  const saveStorage = async () => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify({
        appointments, settings, stewardsList, stationsList, activeAlertMessage, dark, currentSteward, currentUsername, isAdmin, activityLog,
      }));
    } catch (error) {
      console.log('Storage save error:', error);
    }
  };

  /* ACTIVITY LOG */
  const logActivity = (action, details = '') => {
    const entry = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: new Date().toISOString(),
      actor: currentSteward || username || 'לא ידוע',
      action,
      details,
    };
    setActivityLog((prev) => [entry, ...prev].slice(0, ACTIVITY_LOG_LIMIT));
  };

  const clearActivityLog = () => {
    Alert.alert('ניקוי יומן פעילות', 'האם למחוק את כל רשומות היומן?', [
      { text: 'ביטול', style: 'cancel' },
      { text: 'מחק', style: 'destructive', onPress: () => setActivityLog([]) },
    ]);
  };

  /* INACTIVITY AUTO-LOGOUT */
  const bumpActivity = () => { lastActivityRef.current = Date.now(); };

  useEffect(() => {
    if (!isLoggedIn) return;
    lastActivityRef.current = Date.now();
    const timer = setInterval(() => {
      if (Date.now() - lastActivityRef.current > INACTIVITY_TIMEOUT_MS) {
        logActivity('ניתוק אוטומטי', `${currentSteward} נותק עקב חוסר פעילות`);
        setIsLoggedIn(false);
        setCurrentSteward('');
        setCurrentUsername('');
        setIsAdmin(false);
        setSettingsModal(false);
        setActiveTab('active');
        Alert.alert('נותקת אוטומטית', 'נותקת מהמערכת עקב חוסר פעילות ממושך. אנא התחבר שוב.');
      }
    }, 30000);
    return () => clearInterval(timer);
  }, [isLoggedIn, currentSteward]);

  /* AUTO DARK MODE */
  useEffect(() => {
    if (!settings.autoDarkMode) return;
    const updateDarkMode = () => {
      const hour = new Date().getHours();
      setDark(hour >= 19 || hour < 6);
    };
    updateDarkMode();
    const timer = setInterval(updateDarkMode, 60000);
    return () => clearInterval(timer);
  }, [settings.autoDarkMode]);

  /* THEME */
  const theme = useMemo(() => ({
    bg: dark ? '#101820' : '#f2f5f8',
    card: dark ? '#1b252d' : '#ffffff',
    sub: dark ? '#222e38' : '#f7f9fb',
    text: dark ? '#ffffff' : '#07345c',
    body: dark ? '#d8e1e8' : '#34404a',
    muted: dark ? '#9caab5' : '#66727d',
    border: dark ? '#34414c' : '#d5dde5',
    input: dark ? '#17222b' : '#ffffff',
  }), [dark]);

  /* FILTERS */
  const getAppointmentTimestamp = (item) => {
    const boardDt = combineDateAndTime(item.boardDate, item.boardTime);
    if (boardDt) return boardDt.getTime();
    const secondaryDt = combineDateAndTime(item.secondaryDate, item.secondaryTime);
    if (secondaryDt) return secondaryDt.getTime();
    return Infinity;
  };

  const active = useMemo(() => {
    return appointments
      .filter((a) => a.status === 'active')
      .slice()
      .sort((a, b) => getAppointmentTimestamp(a) - getAppointmentTimestamp(b));
  }, [appointments]);
  const closed = useMemo(() => appointments.filter((a) => a.status === 'closed'), [appointments]);

  const filteredActive = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return active;
    return active.filter((a) =>
      [a.passengerName, a.passengerPhone, a.boardTrainNum, a.secondaryTrainNum, a.fromStation, a.toStation, a.disabilityType, a.helpType]
        .some((value) => String(value || '').toLowerCase().includes(q))
    );
  }, [active, search]);

  const filteredStations = useMemo(() => {
    const q = stationSearch.trim();
    if (!q) return stationsList;
    return stationsList.filter((station) => station.includes(q));
  }, [stationsList, stationSearch]);

  /* LOGIN */
  const login = () => {
    const cleanUsername = username.trim();
    if (!cleanUsername || !password) {
      Alert.alert('חסר מידע', 'נא להזין שם משתמש וסיסמה.');
      return;
    }

    const lockedUntil = lockouts[cleanUsername];
    if (lockedUntil && Date.now() < lockedUntil) {
      const minutesLeft = Math.ceil((lockedUntil - Date.now()) / 60000);
      Alert.alert('נעילה זמנית', `בוצעו יותר מדי ניסיונות התחברות כושלים. נא לנסות שוב בעוד כ-${minutesLeft} דקות.`);
      return;
    }

    const found = stewardsList.find((s) => s.username === cleanUsername && s.password === password);
    if (!found) {
      const nextAttempts = (loginAttempts[cleanUsername] || 0) + 1;
      if (nextAttempts >= MAX_LOGIN_ATTEMPTS) {
        setLockouts((prev) => ({ ...prev, [cleanUsername]: Date.now() + LOGIN_LOCKOUT_MS }));
        setLoginAttempts((prev) => ({ ...prev, [cleanUsername]: 0 }));
        logActivity('נעילה זמנית', `שם משתמש ${cleanUsername} ננעל ל-5 דקות אחרי ${MAX_LOGIN_ATTEMPTS} ניסיונות כושלים`);
        Alert.alert('נעילה זמנית', `בוצעו יותר מדי ניסיונות התחברות כושלים. החשבון ננעל ל-5 דקות.`);
      } else {
        setLoginAttempts((prev) => ({ ...prev, [cleanUsername]: nextAttempts }));
        logActivity('ניסיון התחברות כושל', `שם משתמש: ${cleanUsername} (ניסיון ${nextAttempts}/${MAX_LOGIN_ATTEMPTS})`);
        Alert.alert('שגיאת התחברות', 'שם המשתמש או הסיסמה אינם נכונים.');
      }
      return;
    }

    setLoginAttempts((prev) => ({ ...prev, [cleanUsername]: 0 }));
    setCurrentSteward(found.name);
    setCurrentUsername(found.username);
    setIsAdmin(Boolean(found.isAdmin));
    setIsLoggedIn(true);
    setUsername('');
    setPassword('');
    logActivity('התחברות', `${found.name} התחבר/ה למערכת`);
    if (found.isAdmin && found.password === DEFAULT_ADMIN_PASSWORD) {
      setTimeout(() => {
        Alert.alert(
          '⚠️ נדרש שינוי סיסמה',
          'אתה מחובר עם סיסמת ברירת המחדל של המנהל. מומלץ מאוד להחליף אותה כעת דרך הגדרות ← שינוי סיסמה אישית.',
          [{ text: 'הבנתי', onPress: () => { if (activeAlertMessage) setShowSystemAlertModal(true); } }]
        );
      }, 300);
    } else if (activeAlertMessage) {
      setTimeout(() => setShowSystemAlertModal(true), 300);
    }
  };

  /* LOGOUT */
  const logout = () => {
    Alert.alert('יציאה מהמערכת', 'האם אתה בטוח שברצונך לצאת?', [
      { text: 'ביטול', style: 'cancel' },
      {
        text: 'יציאה',
        style: 'destructive',
        onPress: () => {
          logActivity('התנתקות', `${currentSteward} התנתק/ה מהמערכת`);
          setIsLoggedIn(false);
          setCurrentSteward('');
          setCurrentUsername('');
          setIsAdmin(false);
          setSettingsModal(false);
          setActiveTab('active');
        },
      },
    ]);
  };

  const updateNew = (patch) => { bumpActivity(); setNewApp((prev) => ({ ...prev, ...patch })); };
  const updateEdit = (patch) => { bumpActivity(); setEditApp((prev) => ({ ...prev, ...patch })); };

  /* STATION */
  const openStation = (field, target = 'new') => {
    setStationField(field);
    setStationTarget(target);
    setStationSearch('');
    setStationModal(true);
  };

  const STATION_FIELD_KEYS = {
    from: 'fromStation',
    to: 'toStation',
    transferFrom: 'transferFromStation',
    transferTo: 'transferToStation',
  };

  const selectStation = (station) => {
    const key = STATION_FIELD_KEYS[stationField] || 'fromStation';
    if (stationTarget === 'edit') {
      updateEdit({ [key]: station });
    } else {
      updateNew({ [key]: station });
    }
    setStationModal(false);
  };

  /* TIME + DATE PICKER */
  const openTime = (field, target = 'new') => {
    setTimeField(field);
    setTimeTarget(target);
    setTimeModal(true);
  };

  const saveTime = (hour, minute, date) => {
    const dateKey = timeField.replace('Time', 'Date');
    const patch = { [timeField]: `${hour}:${minute}` };
    if (date) patch[dateKey] = date;
    if (timeTarget === 'edit') {
      updateEdit(patch);
    } else {
      updateNew(patch);
    }
    setTimeModal(false);
  };

  /* PLATFORM PICKER (רציף) */
  const openPlatform = (field, target = 'new') => {
    setPlatformField(field);
    setPlatformTarget(target);
    setPlatformModal(true);
  };

  const savePlatform = (value) => {
    if (platformTarget === 'edit') {
      updateEdit({ [platformField]: value });
    } else {
      updateNew({ [platformField]: value });
    }
    setPlatformModal(false);
  };

  /* CARS PICKER (מספר קרונות) */
  const openCars = (field, target = 'new') => {
    setCarsField(field);
    setCarsTarget(target);
    setCarsModal(true);
  };

  const saveCars = (value) => {
    if (carsTarget === 'edit') {
      updateEdit({ [carsField]: value });
    } else {
      updateNew({ [carsField]: value });
    }
    setCarsModal(false);
  };

  /* OFFLINE DETECTION — no external packages, so connectivity is checked with a lightweight,
     short-timeout network request run on load and every 15 seconds. */
  useEffect(() => {
    let cancelled = false;
    const checkConnection = async () => {
      try {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 5000);
        await fetch('https://www.google.com/generate_204', { method: 'HEAD', signal: controller.signal });
        clearTimeout(timer);
        if (!cancelled) setIsOffline(false);
      } catch (e) {
        if (!cancelled) setIsOffline(true);
      }
    };
    checkConnection();
    const interval = setInterval(checkConnection, 15000);
    return () => { cancelled = true; clearInterval(interval); };
  }, []);

  /* CLEAR CACHE — clears transient/local data (activity log) without touching appointments,
     stewards, stations or settings. */
  const clearCache = () => {
    Alert.alert('ניקוי מטמון', 'לנקות נתונים זמניים (כגון יומן פעילות)? התיאומים וההגדרות לא יימחקו.', [
      { text: 'ביטול', style: 'cancel' },
      {
        text: 'נקה',
        style: 'destructive',
        onPress: () => {
          bumpActivity();
          setActivityLog([]);
          setSearch('');
          setStationSearch('');
          Alert.alert('בוצע', 'המטמון נוקה בהצלחה.');
        },
      },
    ]);
  };

  /* תזכורות (ללא חבילות חיצוניות) */
  const alertedIdsRef = useRef(new Set());
  const reminderIntervalRef = useRef(null);

  useEffect(() => {
    const checkReminders = () => {
      const now = Date.now();
      appointments.forEach((item) => {
        if (item.status !== 'active') return;
        const appointmentDate = combineDateAndTime(item.boardDate, item.boardTime);
        if (!appointmentDate) return;
        const minutesLeft = (appointmentDate.getTime() - now) / 60000;
        const alreadyAlerted = alertedIdsRef.current.has(item.id);

        if (!alreadyAlerted && minutesLeft > 0 && minutesLeft <= REMINDER_MINUTES_BEFORE) {
          alertedIdsRef.current.add(item.id);
          Vibration.vibrate([0, 400, 200, 400, 200, 400]);
          Alert.alert(
            '🔔 תזכורת: תיאום מתקרב',
            `בעוד כ-${Math.max(1, Math.round(minutesLeft))} דקות — ${item.fromStation} ← ${item.toStation}, רכבת ${item.boardTrainNum || '—'} בשעה ${item.boardTime}${item.passengerName ? `\nנוסע: ${item.passengerName}` : ''}`
          );
        }
      });
    };

    reminderIntervalRef.current = setInterval(checkReminders, 20000);
    checkReminders();
    return () => {
      if (reminderIntervalRef.current) clearInterval(reminderIntervalRef.current);
    };
  }, [appointments]);

  const clearReminderFlag = (id) => {
    alertedIdsRef.current.delete(id);
  };

  /* VALIDATE */
  const validateAppointment = (app) => {
    if (!app.fromStation) return 'נא לבחור תחנת מוצא.';
    if (!app.toStation) return 'נא לבחור תחנת יעד.';
    if (app.fromStation === app.toStation) return 'תחנת המוצא ותחנת היעד אינן יכולות להיות זהות.';
    if (!app.boardTrainNum) return 'נא להזין מספר רכבת.';
    if (!isValidDate(app.boardDate)) return 'נא לבחור תאריך תקין לרכבת.';
    if (!isValidTime(app.boardTime)) return 'נא לבחור שעה תקינה לרכבת.';

    if (app.boardType === 'להעלות' && app.transferEnabled) {
      if (!app.transferFromStation) return 'נא לבחור תחנת מוצא להחלפה.';
      if (!app.transferToStation) return 'נא לבחור תחנת יעד להחלפה.';
      if (app.transferFromStation === app.transferToStation) return 'תחנות ההחלפה אינן יכולות להיות זהות.';
    }

    if (app.boardType === 'להוריד ולהעלות') {
      if (!app.secondaryTrainNum) return 'נא להזין מספר רכבת המשך.';
      if (!isValidDate(app.secondaryDate)) return 'נא לבחור תאריך תקין לרכבת ההמשך.';
      if (!isValidTime(app.secondaryTime)) return 'נא לבחור שעה תקינה לרכבת ההמשך.';

      const first = getMinutes(app.boardTime);
      const second = getMinutes(app.secondaryTime);
      if (first !== null && second !== null && second < first) {
        return 'שעת רכבת ההמשך אינה יכולה להיות מוקדמת משעת הרכבת הראשונה.';
      }
    }

    if (app.isUnscheduled) {
      if (!app.passengerName.trim()) return 'בהגעה ללא תיאום חובה לציין שם נוסע.';
      if (!isValidPhone(app.passengerPhone)) return 'בהגעה ללא תיאום חובה לציין מספר טלפון תקין.';
    }

    return null;
  };

  /* ADD */
  const addAppointment = async () => {
    if (saving) return;
    bumpActivity();
    if (activeAlertMessage) {
      setShowSystemAlertModal(true);
      return;
    }

    const error = validateAppointment(newApp);
    if (error) {
      Alert.alert('בדיקת פרטים', error);
      return;
    }

    setSaving(true);
    try {
      const now = new Date().toISOString();
      const item = {
        ...newApp,
        id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
        status: 'active',
        createdAt: now,
        updatedAt: now,
        createdBy: currentSteward,
        closedBy: '',
        closedAt: '',
      };
      if (!item.passengerName.trim()) item.passengerName = 'לא צוין (מתואם)';

      setAppointments((prev) => [item, ...prev]);
      setNewApp(createEmptyAppointment(settings.defaultHomeStation));
      setActiveTab('active');
      Alert.alert('נשמר בהצלחה', 'התיאום נוסף לרשימת התיאומים הפעילים.');
    } finally {
      setSaving(false);
    }
  };

  /* EDIT */
  const startEdit = (item) => {
    setEditingId(item.id);
    setEditApp({ ...createEmptyAppointment(settings.defaultHomeStation), ...item });
    setEditModal(true);
  };

  const saveEditedAppointment = () => {
    if (!editingId) return;
    bumpActivity();
    const error = validateAppointment(editApp);
    if (error) {
      Alert.alert('בדיקת פרטים', error);
      return;
    }

    clearReminderFlag(editingId);
    const now = new Date().toISOString();
    const updated = {
      ...editApp,
      passengerName: editApp.passengerName.trim() || 'לא צוין (מתואם)',
      updatedAt: now,
    };

    setAppointments((prev) => prev.map((item) => (item.id === editingId ? { ...item, ...updated } : item)));

    setEditModal(false);
    setEditingId(null);
    Alert.alert('עודכן בהצלחה', 'פרטי התיאום עודכנו.');
  };

  /* CLOSE */
  const closeAppointment = (item) => {
    Alert.alert('סיום תיאום', 'האם אתה בטוח שהתיאום בוצע בהצלחה?', [
      { text: 'ביטול', style: 'cancel' },
      {
        text: 'בוצע',
        onPress: () => {
          bumpActivity();
          clearReminderFlag(item.id);
          const now = new Date().toISOString();
          const updatedItem = { ...item, status: 'closed', closedBy: currentSteward, closedAt: now, updatedAt: now };

          setAppointments((prev) => prev.map((a) => (a.id === item.id ? updatedItem : a)));

          if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
          setToast(item);
          toastTimerRef.current = setTimeout(() => setToast(null), 7000);
        },
      },
    ]);
  };

  /* UNDO */
  const undo = () => {
    if (!toast) return;
    bumpActivity();
    setAppointments((prev) => prev.map((item) =>
      item.id === toast.id
        ? { ...item, status: 'active', closedBy: '', closedAt: '', updatedAt: new Date().toISOString() }
        : item
    ));
    setToast(null);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
  };

  /* PHONE */
  const call = async (phone) => {
    if (!phone) return;
    bumpActivity();
    try {
      await Linking.openURL(`tel:${phone}`);
    } catch {
      Alert.alert('חיוג', 'לא ניתן לפתוח חיוג במכשיר זה.');
    }
  };

  /* TRAIN SCHEDULE (opens in external browser) */
  const openSchedule = async () => {
    bumpActivity();
    if (isOffline) {
      Alert.alert('אין חיבור לאינטרנט', 'לא ניתן לפתוח את לוח הזמנים במצב לא מקוון.');
      return;
    }
    try {
      await Linking.openURL(TRAIN_SCHEDULE_URL);
    } catch {
      Alert.alert('לוח זמנים', 'לא ניתן לפתוח את לוח הזמנים כרגע.');
    }
  };

  /* WHATSAPP (with web fallback) */
  const whatsapp = async (phone, customText) => {
    if (!phone) return;
    bumpActivity();
    const number = normalizePhoneForWhatsApp(phone);
    const text = customText || 'שלום, מדבר דייל רכבת ישראל. אני מתאם איתך את העזרה ברציף.';
    const appUrl = `whatsapp://send?phone=${number}&text=${encodeURIComponent(text)}`;
    const webUrl = `https://wa.me/${number}?text=${encodeURIComponent(text)}`;

    try {
      const supported = await Linking.canOpenURL(appUrl);
      await Linking.openURL(supported ? appUrl : webUrl);
    } catch {
      try {
        await Linking.openURL(webUrl);
      } catch {
        Alert.alert('WhatsApp', 'לא ניתן לפתוח WhatsApp.');
      }
    }
  };

  /* REPORT */
  const sendReport = async () => {
    const text = `📋 דוח משמרת - מערכת נגישות\n\nדייל: ${currentSteward}\nתיאומים שבוצעו: ${closed.length}\nתיאומים פעילים: ${active.length}\nתאריך: ${new Date().toLocaleDateString('he-IL')}`;
    await whatsapp(settings.managerPhone, text);
  };

  const updateSettings = (patch) => setSettings((prev) => ({ ...prev, ...patch }));

  /* STEWARDS */
  const addSteward = ({ name, user, pass }) => {
    const cleanName = name.trim();
    const cleanUser = user.trim();

    if (!cleanName || !cleanUser || !pass) {
      Alert.alert('שגיאה', 'נא למלא שם, מספר עובד וסיסמה.');
      return false;
    }
    if (stewardsList.some((item) => item.username === cleanUser)) {
      Alert.alert('שגיאה', 'מספר העובד כבר קיים.');
      return false;
    }
    const strengthError = validatePasswordStrength(pass);
    if (strengthError) {
      Alert.alert('סיסמה חלשה מדי', strengthError);
      return false;
    }

    setStewardsList((prev) => [...prev, { username: cleanUser, password: pass, name: cleanName, isAdmin: false }]);
    logActivity('הוספת דייל', `${currentSteward} הוסיף/ה את הדייל ${cleanName} (${cleanUser})`);
    Alert.alert('הצלחה', 'הדייל נוסף למערכת.');
    return true;
  };

  const removeSteward = (user) => {
    const target = stewardsList.find((item) => item.username === user);
    if (!target) return;

    if (target.username === ADMIN_USERNAME) {
      Alert.alert('פעולה חסומה', 'לא ניתן למחוק את מנהל המערכת הראשי.');
      return;
    }

    Alert.alert('מחיקת דייל', `האם להסיר את הגישה של ${target.name}?`, [
      { text: 'ביטול', style: 'cancel' },
      {
        text: 'הסר',
        style: 'destructive',
        onPress: () => {
          setStewardsList((prev) => prev.filter((item) => item.username !== user));
          logActivity('הסרת דייל', `${currentSteward} הסיר/ה את הגישה של ${target.name} (${user})`);
        },
      },
    ]);
  };

  /* ADMIN: RESET ANOTHER STEWARD'S PASSWORD */
  const resetStewardPassword = ({ user, newPass }) => {
    const cleanUser = String(user || '').trim();
    const target = stewardsList.find((item) => item.username === cleanUser);
    if (!target) {
      Alert.alert('שגיאה', 'לא נמצא דייל עם מספר עובד זה.');
      return false;
    }
    const strengthError = validatePasswordStrength(newPass);
    if (strengthError) {
      Alert.alert('סיסמה חלשה מדי', strengthError);
      return false;
    }
    setStewardsList((prev) => prev.map((item) => (item.username === cleanUser ? { ...item, password: newPass } : item)));
    logActivity('איפוס סיסמה על ידי מנהל', `${currentSteward} איפס/ה את הסיסמה של ${target.name} (${cleanUser})`);
    Alert.alert('הצלחה', `הסיסמה של ${target.name} עודכנה בהצלחה.`);
    return true;
  };

  /* CHANGE OWN PASSWORD */
  const changePassword = ({ oldPass, newPass, confirmPass }) => {
    const account = stewardsList.find((item) => item.username === currentUsername);
    if (!account) {
      Alert.alert('שגיאה', 'לא נמצא חשבון מחובר.');
      return false;
    }
    if (account.password !== oldPass) {
      Alert.alert('שגיאה', 'הסיסמה הנוכחית שגויה.');
      return false;
    }
    const strengthError = validatePasswordStrength(newPass);
    if (strengthError) {
      Alert.alert('סיסמה חלשה מדי', strengthError);
      return false;
    }
    if (newPass !== confirmPass) {
      Alert.alert('שגיאה', 'הסיסמה החדשה ואימות הסיסמה אינם תואמים.');
      return false;
    }
    if (newPass === oldPass) {
      Alert.alert('שגיאה', 'הסיסמה החדשה חייבת להיות שונה מהסיסמה הנוכחית.');
      return false;
    }
    setStewardsList((prev) => prev.map((item) => (item.username === currentUsername ? { ...item, password: newPass } : item)));
    logActivity('שינוי סיסמה', `${currentSteward} עדכן/ה את הסיסמה האישית`);
    Alert.alert('הצלחה', 'הסיסמה עודכנה בהצלחה.');
    return true;
  };

  /* STATIONS */
  const addStation = (name) => {
    const cleanName = String(name || '').trim();
    if (!cleanName) {
      Alert.alert('שגיאה', 'נא להזין שם תחנה.');
      return false;
    }
    if (stationsList.includes(cleanName)) {
      Alert.alert('שגיאה', 'התחנה כבר קיימת ברשימה.');
      return false;
    }
    setStationsList((prev) => normalizeStations([...prev, cleanName]));
    logActivity('הוספת תחנה', `${currentSteward} הוסיף/ה את תחנת "${cleanName}"`);
    return true;
  };

  const removeStation = (name) => {
    Alert.alert('מחיקת תחנה', `האם להסיר את "${name}" מרשימת התחנות?`, [
      { text: 'ביטול', style: 'cancel' },
      {
        text: 'הסר',
        style: 'destructive',
        onPress: () => {
          setStationsList((prev) => prev.filter((item) => item !== name));
          logActivity('הסרת תחנה', `${currentSteward} הסיר/ה את תחנת "${name}"`);
        },
      },
    ]);
  };

  /* RESET */
  const resetLocalData = () => {
    Alert.alert('איפוס נתונים', 'פעולה זו תמחק את התיאומים וההגדרות המקומיות מהמכשיר.', [
      { text: 'ביטול', style: 'cancel' },
      {
        text: 'איפוס',
        style: 'destructive',
        onPress: async () => {
          try {
            await AsyncStorage.removeItem(STORAGE_KEY);
            setAppointments([]);
            setSettings(createDefaultSettings());
            setStewardsList(createDefaultStewards());
            setStationsList(normalizeStations(FALLBACK_STATIONS));
            setActiveAlertMessage('');
            setActivityLog([]);
            setLoginAttempts({});
            setLockouts({});
            setCurrentSteward('');
            setCurrentUsername('');
            setIsAdmin(false);
            setIsLoggedIn(false);
            Alert.alert('הסתיים', 'הנתונים המקומיים אופסו.');
          } catch {
            Alert.alert('שגיאה', 'לא ניתן לאפס את הנתונים.');
          }
        },
      },
    ]);
  };

  useEffect(() => () => {
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
  }, []);

  /* SPLASH INTRO — short branded animation shown once when the app first opens */
  if (showSplash) {
    return <SplashScreen onFinish={() => setShowSplash(false)} />;
  }

  /* LOADING */
  if (!ready) {
    return (
      <SafeAreaView style={styles.loading}>
        <StatusBar barStyle="dark-content" />
        <TrainLoader />
        <Text style={styles.loadingTitle}>מערכת ניהול נגישות</Text>
        <Text style={styles.loadingText}>טוען נתונים...</Text>
      </SafeAreaView>
    );
  }

  /* LOGIN SCREEN */
  if (!isLoggedIn) {
    return (
      <SafeAreaView style={[styles.loginBg, { backgroundColor: dark ? '#071019' : '#002b4d' }]}>
        <StatusBar barStyle="light-content" />
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={styles.loginWrap}>
          <ScrollView contentContainerStyle={styles.loginCard} keyboardShouldPersistTaps="handled">
            {!settings.autoDarkMode && (
              <TouchableOpacity
                style={styles.darkBtn}
                onPress={() => setDark((v) => !v)}
                accessibilityRole="button"
                accessibilityLabel={dark ? 'עבור למצב בהיר' : 'עבור למצב כהה'}
              >
                <Ionicons name={dark ? 'sunny' : 'moon'} size={19} color={dark ? '#ffd34d' : '#07345c'} />
              </TouchableOpacity>
            )}

            <View style={[styles.brand, { backgroundColor: dark ? '#1c2933' : '#eef3f8' }]}>
              <View style={styles.logo}>
                <FontAwesome5 name="train" size={22} color="#fff" />
                <View style={styles.logoAccessBadge}>
                  <Ionicons name="accessibility" size={12} color="#fff" />
                </View>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.brandTitle, { color: dark ? '#fff' : '#07345c' }]}>רכבת ישראל</Text>
                <Text style={[styles.brandSub, { color: dark ? '#aab7c1' : '#66727d' }]}>ניהול נגישות דיילים</Text>
              </View>
            </View>

            <Text style={[styles.label, { color: dark ? '#d8e1e8' : '#34404a' }]}>שם משתמש / מספר עובד</Text>
            <Input icon="person-outline" theme={{ input: dark ? '#17222b' : '#fff', border: dark ? '#34414c' : '#d5dde5', text: dark ? '#fff' : '#07345c', muted: '#8a949d' }} value={username} onChangeText={setUsername} placeholder="הכנס מספר עובד" keyboardType="numeric" autoCapitalize="none" accessibilityLabel="שם משתמש" />

            <Text style={[styles.label, { color: dark ? '#d8e1e8' : '#34404a' }]}>סיסמה</Text>
            <Input icon="lock-closed-outline" theme={{ input: dark ? '#17222b' : '#fff', border: dark ? '#34414c' : '#d5dde5', text: dark ? '#fff' : '#07345c', muted: '#8a949d' }} value={password} onChangeText={setPassword} placeholder="הכנס סיסמה" secureTextEntry accessibilityLabel="סיסמה" />

            <TouchableOpacity style={styles.primary} onPress={login} accessibilityRole="button" accessibilityLabel="כניסה למערכת">
              <Text style={styles.primaryText}>כניסה למערכת</Text>
              <Ionicons name="arrow-back" size={19} color="#fff" />
            </TouchableOpacity>

            <Text style={[styles.loginDisclaimer, { color: dark ? '#9caab5' : '#66727d' }]}>גרסה מקומית ל־Expo Go</Text>
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  }

  /* MAIN */
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <StatusBar barStyle={dark ? 'light-content' : 'dark-content'} />

      {/* HEADER */}
      <View style={styles.header}>
        <View style={styles.headerRow}>
          <View style={styles.titleRow}>
            <View style={styles.headerLogoBadge}>
              <FontAwesome5 name="train" size={16} color="#fff" />
              <View style={styles.headerLogoAccessBadge}>
                <Ionicons name="accessibility" size={10} color="#fff" />
              </View>
            </View>
            <Text style={styles.headerTitle}>ניהול נגישות ברכבת</Text>
          </View>

          <View style={styles.headerActions}>
            {activeAlertMessage ? (
              <TouchableOpacity
                style={[styles.circleBtn, { backgroundColor: '#d9534f' }]}
                onPress={() => setShowSystemAlertModal(true)}
                accessibilityRole="button"
                accessibilityLabel="הצג התראת מערכת פעילה"
              >
                <Ionicons name="warning" size={18} color="#fff" />
              </TouchableOpacity>
            ) : null}

            <TouchableOpacity style={styles.circleBtn} onPress={openSchedule} accessibilityRole="button" accessibilityLabel="פתח לוח זמנים רכבת ישראל">
              <Ionicons name="time-outline" size={18} color="#fff" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.circleBtn} onPress={() => { bumpActivity(); setSettingsModal(true); }} accessibilityRole="button" accessibilityLabel="פתח הגדרות">
              <Ionicons name="settings-outline" size={18} color="#fff" />
            </TouchableOpacity>

            {!settings.autoDarkMode && (
              <TouchableOpacity style={styles.circleBtn} onPress={() => setDark((v) => !v)} accessibilityRole="button" accessibilityLabel={dark ? 'עבור למצב בהיר' : 'עבור למצב כהה'}>
                <Ionicons name={dark ? 'sunny' : 'moon'} size={18} color="#ffd34d" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        <Text style={styles.user}>שלום, {currentSteward}{isAdmin ? '  • מנהל' : ''}</Text>
      </View>

      {/* OFFLINE BANNER */}
      {isOffline && (
        <View style={styles.offlineBanner}>
          <Ionicons name="cloud-offline-outline" size={16} color="#7d6416" />
          <Text style={styles.offlineBannerText}>אין חיבור לאינטרנט — האפליקציה פועלת במצב לא מקוון, הנתונים נשמרים מקומית בטלפון</Text>
        </View>
      )}

      {/* TABS */}
      <View style={styles.tabs}>
        <TabButton label={`פעילים (${active.length})`} active={activeTab === 'active'} onPress={() => { bumpActivity(); setActiveTab('active'); }} />
        <TabButton
          label="＋ תיאום חדש"
          active={activeTab === 'new'}
          onPress={() => {
            bumpActivity();
            if (activeAlertMessage) {
              setShowSystemAlertModal(true);
              return;
            }
            setActiveTab('new');
          }}
        />
        <TabButton label={`היסטוריה (${closed.length})`} active={activeTab === 'closed'} onPress={() => { bumpActivity(); setActiveTab('closed'); }} />
      </View>

      {/* CONTENT */}
      <View style={{ flex: 1 }}>
        {activeTab === 'active' && (
          <View style={{ flex: 1 }}>
            <View style={styles.contentTop}>
              <View style={styles.titleWithScheduleRow}>
                <Text style={[styles.sectionTitle, { color: theme.text, marginBottom: 0 }]}>תיאומים פעילים להיום</Text>
                <TouchableOpacity style={styles.scheduleBtn} onPress={openSchedule} accessibilityRole="button" accessibilityLabel="פתח לוח זמנים רכבת ישראל">
                  <Ionicons name="time-outline" size={15} color="#0a5c9e" />
                  <Text style={styles.scheduleBtnText}>לוח זמנים</Text>
                </TouchableOpacity>
              </View>
              <Input icon="search" theme={theme} value={search} onChangeText={setSearch} placeholder="חפש לפי שם, רכבת, תחנה או טלפון..." accessibilityLabel="חיפוש תיאומים" />
            </View>

            <FlatList
              data={filteredActive}
              keyExtractor={(item) => item.id}
              renderItem={({ item }) => (
                <AppointmentCard item={item} theme={theme} dark={dark} onClose={closeAppointment} onCall={call} onWhatsapp={whatsapp} onEdit={startEdit} />
              )}
              contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 40 }}
              keyboardShouldPersistTaps="handled"
              ListEmptyComponent={<Empty theme={theme} text={search ? 'לא נמצאו תיאומים התואמים לחיפוש.' : 'אין כרגע תיאומים פעילים.'} />}
            />
          </View>
        )}

        {activeTab === 'new' && (
          <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
            <ScrollView style={styles.content} contentContainerStyle={{ paddingBottom: 50 }} keyboardShouldPersistTaps="handled">
              <NewAppointmentScreen
                app={newApp}
                update={updateNew}
                theme={theme}
                openStation={(field) => openStation(field, 'new')}
                openTime={(field) => openTime(field, 'new')}
                openPlatform={(field) => openPlatform(field, 'new')}
                openCars={(field) => openCars(field, 'new')}
                onSave={addAppointment}
                saving={saving}
                onCall={() => call('077-5704506')}
              />
            </ScrollView>
          </KeyboardAvoidingView>
        )}

        {activeTab === 'closed' && (
          <FlatList
            data={closed}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ padding: 16, paddingBottom: 40 }}
            ListHeaderComponent={<Text style={[styles.sectionTitle, { color: theme.text, marginBottom: 14 }]}>היסטוריית תיאומים</Text>}
            ListEmptyComponent={<Empty theme={theme} text="אין היסטוריית תיאומים." />}
            renderItem={({ item }) => <HistoryCard item={item} theme={theme} />}
          />
        )}
      </View>

      {/* UNDO TOAST */}
      {toast && (
        <View style={styles.toast}>
          <View style={{ flex: 1 }}>
            <Text style={styles.toastText}>התיאום סומן כמבוצע</Text>
            <Text style={styles.toastSubText}>אפשר לבטל את הפעולה בתוך מספר שניות</Text>
          </View>
          <TouchableOpacity onPress={undo} style={styles.undo} accessibilityRole="button" accessibilityLabel="בטל סימון כבוצע">
            <Text style={styles.undoText}>בטל</Text>
          </TouchableOpacity>
        </View>
      )}

      <SettingsModal
        visible={settingsModal}
        onClose={() => setSettingsModal(false)}
        theme={theme}
        settings={settings}
        updateSettings={updateSettings}
        closedCount={closed.length}
        activeCount={active.length}
        onReport={sendReport}
        onCall={call}
        isAdmin={isAdmin}
        stewardsList={stewardsList}
        addSteward={addSteward}
        removeSteward={removeSteward}
        stationsList={stationsList}
        addStation={addStation}
        removeStation={removeStation}
        changePassword={changePassword}
        resetStewardPassword={resetStewardPassword}
        activityLog={activityLog}
        clearActivityLog={clearActivityLog}
        activeAlertMessage={activeAlertMessage}
        setActiveAlertMessage={setActiveAlertMessage}
        onReset={resetLocalData}
        onLogout={logout}
        onClearCache={clearCache}
      />

      <SystemAlertModal visible={showSystemAlertModal} message={activeAlertMessage} onClose={() => setShowSystemAlertModal(false)} />

      <StationModal
        visible={stationModal}
        field={stationField}
        theme={theme}
        search={stationSearch}
        setSearch={setStationSearch}
        stations={filteredStations}
        onSelect={selectStation}
        onClose={() => setStationModal(false)}
      />

      <EditAppointmentModal
        visible={editModal}
        app={editApp}
        update={updateEdit}
        theme={theme}
        onClose={() => { setEditModal(false); setEditingId(null); }}
        onSave={saveEditedAppointment}
        openStation={(field) => openStation(field, 'edit')}
        openTime={(field) => openTime(field, 'edit')}
        openPlatform={(field) => openPlatform(field, 'edit')}
        openCars={(field) => openCars(field, 'edit')}
      />

      <TimePickerModal
        visible={timeModal}
        initialValue={timeTarget === 'edit' ? editApp[timeField] : newApp[timeField]}
        initialDate={timeTarget === 'edit' ? editApp[timeField.replace('Time', 'Date')] : newApp[timeField.replace('Time', 'Date')]}
        onClose={() => setTimeModal(false)}
        onSave={saveTime}
      />

      <PlatformPickerModal
        visible={platformModal}
        initialValue={platformTarget === 'edit' ? editApp[platformField] : newApp[platformField]}
        onClose={() => setPlatformModal(false)}
        onSave={savePlatform}
      />

      <CarsPickerModal
        visible={carsModal}
        initialValue={carsTarget === 'edit' ? editApp[carsField] : newApp[carsField]}
        onClose={() => setCarsModal(false)}
        onSave={saveCars}
      />
    </SafeAreaView>
  );
}

/* =========================================================
   TAB
========================================================= */

function TabButton({ label, active, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.tab, active && styles.tabActive]} accessibilityRole="tab" accessibilityState={{ selected: active }} accessibilityLabel={label}>
      <Text style={[styles.tabText, active && styles.tabTextActive]}>{label}</Text>
    </TouchableOpacity>
  );
}

/* =========================================================
   INPUT
========================================================= */

function Input({ icon, theme, value, onChangeText, placeholder, accessibilityLabel, ...props }) {
  return (
    <View style={[styles.inputWrap, { backgroundColor: theme.input, borderColor: theme.border }]}>
      <Ionicons name={icon} size={19} color={theme.muted} />
      <TextInput
        {...props}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#8a949d"
        style={[styles.input, { color: theme.text }]}
        accessibilityLabel={accessibilityLabel || placeholder}
      />
    </View>
  );
}

/* =========================================================
   APPOINTMENT CARD
========================================================= */

function AppointmentCard({ item, theme, dark, onClose, onCall, onWhatsapp, onEdit }) {
  const [showPhone, setShowPhone] = useState(false);
  const firstTime = getMinutes(item.boardTime);
  const secondTime = getMinutes(item.secondaryTime);
  const transferMinutes = firstTime !== null && secondTime !== null ? secondTime - firstTime : null;
  const shortTransfer = item.boardType === 'להוריד ולהעלות' && transferMinutes !== null && transferMinutes >= 0 && transferMinutes < 10;

  return (
    <View style={[styles.card, { backgroundColor: theme.card, borderRightColor: item.isUnscheduled ? '#ff4d4d' : '#0a5c9e' }]}>
      <View style={styles.cardTop}>
        <View style={styles.cardTopLeft}>
          {item.isUnscheduled && (
            <View style={styles.badgeRed}>
              <Ionicons name="alert-circle" size={14} color="#fff" />
              <Text style={styles.redText}>ללא תיאום</Text>
            </View>
          )}
          <View style={styles.badgeOrange}>
            <Ionicons name="calendar-outline" size={14} color="#f56600" />
            <Text style={styles.orangeText}>{formatDateShort(item.boardDate)}  •  {item.boardTime}</Text>
          </View>
        </View>

        <TouchableOpacity style={styles.editCircle} onPress={() => onEdit(item)} accessibilityRole="button" accessibilityLabel="ערוך תיאום">
          <Ionicons name="pencil" size={15} color="#fff" />
        </TouchableOpacity>
      </View>

      <View style={[styles.actionBadge, { backgroundColor: dark ? '#23394a' : '#edf5fb' }]}>
        <Text style={[styles.actionBadgeText, { color: dark ? '#8cc8ff' : '#064b82' }]}>פעולה: {item.boardType}</Text>
      </View>

      <View style={[styles.route, { backgroundColor: theme.sub }]}>
        <View style={styles.routeStation}>
          <Text style={styles.routeLabel}>מוצא</Text>
          <Text style={[styles.routeName, { color: theme.text }]}>{item.fromStation}</Text>
        </View>
        <Ionicons name="train" size={22} color="#0a5c9e" />
        <View style={styles.routeStation}>
          <Text style={styles.routeLabel}>יעד</Text>
          <Text style={[styles.routeName, { color: theme.text }]}>{item.toStation}</Text>
        </View>
      </View>

      <View style={[styles.details, { backgroundColor: theme.sub }]}>
        <Row icon="person-outline" theme={theme} text={<><B c={theme.text}>נוסע:</B> {item.passengerName}</>}>
          {item.passengerPhone ? (
            <View style={styles.quick}>
              <TouchableOpacity style={styles.whatsapp} onPress={() => onWhatsapp(item.passengerPhone)} accessibilityRole="button" accessibilityLabel="שלח הודעת WhatsApp לנוסע">
                <Ionicons name="logo-whatsapp" size={17} color="#fff" />
              </TouchableOpacity>
              <TouchableOpacity style={styles.call} onPress={() => onCall(item.passengerPhone)} accessibilityRole="button" accessibilityLabel="התקשר לנוסע">
                <Ionicons name="call" size={17} color="#fff" />
              </TouchableOpacity>
            </View>
          ) : null}
        </Row>

        {item.passengerPhone ? (
          <Row
            icon="call-outline"
            theme={theme}
            text={<><B c={theme.text}>טלפון:</B> {showPhone ? item.passengerPhone : maskPhone(item.passengerPhone)}</>}
          >
            <TouchableOpacity onPress={() => setShowPhone((v) => !v)} accessibilityRole="button" accessibilityLabel={showPhone ? 'הסתר מספר טלפון' : 'הצג מספר טלפון'} style={{ marginRight: 6 }}>
              <Ionicons name={showPhone ? 'eye-off-outline' : 'eye-outline'} size={17} color={theme.muted} />
            </TouchableOpacity>
          </Row>
        ) : null}

        <Row icon="accessibility-outline" theme={theme} text={<><B c={theme.text}>מוגבלות:</B> <Text style={styles.redStrong}>{item.disabilityType}</Text></>} />
        <Row icon="construct-outline" theme={theme} text={<><B c={theme.text}>עזרה:</B> <Text style={styles.blueStrong}>{item.helpType}</Text></>} />
      </View>

      {item.boardType !== 'להעלות' && (
        <TrainActionBox
          title={item.boardType === 'להוריד ולהעלות' ? '📍 פעולת הורדה' : '📍 פרטי רכבת'}
          trainNumber={item.boardTrainNum}
          date={item.boardDate}
          time={item.boardTime}
          platform={item.boardPlatform}
          cars={item.boardCarsNum}
          location={item.boardCarLocation}
          theme={theme}
          accent="#0a5c9e"
        />
      )}

      {item.boardType === 'להוריד ולהעלות' && (
        <View style={[styles.actionSectionBox, { backgroundColor: theme.sub, borderColor: shortTransfer ? '#d9534f' : '#f56600' }]}>
          <Text style={[styles.actionSectionTitle, { color: '#f56600' }]}>🔄 רכבת המשך / העלאה</Text>

          <View style={styles.actionDetailsGrid}>
            <Info label="רכבת" value={item.secondaryTrainNum} theme={theme} />
            <Info label="תאריך" value={formatDateShort(item.secondaryDate) || 'לא צוין'} theme={theme} />
            <Info label="שעה" value={item.secondaryTime} theme={theme} />
            <Info label="רציף" value={item.secondaryPlatform || 'לא צוין'} theme={theme} />
            <Info label="קרון נכים" value={item.secondaryCarLocation} theme={theme} />
          </View>

          {shortTransfer && (
            <View style={styles.transferAlertBadge}>
              <Ionicons name="warning" size={15} color="#d9534f" />
              <Text style={styles.transferAlertText}>החלפה קצרה! הפרש של {transferMinutes} דקות בלבד.</Text>
            </View>
          )}

          <TrainVisualizer totalCars={item.secondaryCarsNum} location={item.secondaryCarLocation} theme={theme} />
        </View>
      )}

      {item.boardType === 'להעלות' && (
        <TrainActionBox
          title="📍 פרטי רכבת להעלאה"
          trainNumber={item.boardTrainNum}
          date={item.boardDate}
          time={item.boardTime}
          platform={item.boardPlatform}
          cars={item.boardCarsNum}
          location={item.boardCarLocation}
          theme={theme}
          accent="#f56600"
        />
      )}

      {item.boardType === 'להעלות' && item.transferEnabled && (
        <View style={[styles.actionSectionBox, { backgroundColor: theme.sub, borderColor: '#f56600' }]}>
          <Text style={[styles.actionSectionTitle, { color: '#f56600' }]}>🔄 החלפת רכבת</Text>
          <View style={styles.actionDetailsGrid}>
            <Info label="מוצא החלפה" value={item.transferFromStation || 'לא צוין'} theme={theme} />
            <Info label="יעד החלפה" value={item.transferToStation || 'לא צוין'} theme={theme} />
          </View>
        </View>
      )}

      {item.stewardNotes ? (
        <View style={styles.note}>
          <Text style={styles.noteText}><B>הערת שטח:</B> {item.stewardNotes}</Text>
        </View>
      ) : null}

      {item.createdBy ? <Text style={[styles.metaText, { color: theme.muted }]}>נוצר על ידי: {item.createdBy}</Text> : null}

      <TouchableOpacity style={styles.doneBtn} onPress={() => onClose(item)} accessibilityRole="button" accessibilityLabel="סמן תיאום כבוצע">
        <Ionicons name="checkmark-circle" size={19} color="#fff" />
        <Text style={styles.doneText}>סמן כבוצע בהצלחה</Text>
      </TouchableOpacity>
    </View>
  );
}

/* =========================================================
   TRAIN ACTION BOX
========================================================= */

function TrainActionBox({ title, trainNumber, date, time, platform, cars, location, theme, accent }) {
  return (
    <View style={[styles.actionSectionBox, { backgroundColor: theme.sub, borderColor: accent }]}>
      <Text style={[styles.actionSectionTitle, { color: accent }]}>{title}</Text>

      <View style={styles.actionDetailsGrid}>
        <Info label="רכבת" value={trainNumber} theme={theme} />
        <Info label="תאריך" value={formatDateShort(date) || 'לא צוין'} theme={theme} />
        <Info label="שעה" value={time} theme={theme} />
        <Info label="רציף" value={platform || 'לא צוין'} theme={theme} />
        <Info label="קרון נכים" value={location} theme={theme} />
      </View>

      <TrainVisualizer totalCars={cars} location={location} theme={theme} />
    </View>
  );
}

/* =========================================================
   TRAIN LOADER (animated, built-in Animated API only)
========================================================= */

/* =========================================================
   SPLASH INTRO
========================================================= */

function SplashScreen({ onFinish }) {
  const scale = useRef(new Animated.Value(0.6)).current;
  const opacity = useRef(new Animated.Value(0)).current; // used for entrance fade-in AND exit fade-out
  const textOpacity = useRef(new Animated.Value(0)).current;
  const textTranslate = useRef(new Animated.Value(14)).current;

  useEffect(() => {
    const sequence = Animated.sequence([
      Animated.parallel([
        Animated.spring(scale, { toValue: 1, friction: 5, tension: 60, useNativeDriver: true }),
        Animated.timing(opacity, { toValue: 1, duration: 420, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(textOpacity, { toValue: 1, duration: 360, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(textTranslate, { toValue: 0, duration: 360, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      ]),
      Animated.delay(650),
      Animated.timing(opacity, { toValue: 0, duration: 320, easing: Easing.in(Easing.quad), useNativeDriver: true }),
    ]);
    sequence.start(() => onFinish && onFinish());
    return () => sequence.stop();
  }, []);

  return (
    <Animated.View style={[styles.splashContainer, { opacity }]}>
      <StatusBar barStyle="light-content" />
      <Animated.View style={[styles.splashLogoBadge, { transform: [{ scale }] }]}>
        <FontAwesome5 name="train" size={38} color="#fff" />
        <View style={styles.splashAccessBadge}>
          <Ionicons name="accessibility" size={20} color="#fff" />
        </View>
      </Animated.View>

      <Animated.View style={{ opacity: textOpacity, transform: [{ translateY: textTranslate }] }}>
        <Text style={styles.splashTitle}>רכבת ישראל</Text>
        <Text style={styles.splashSubtitle}>ניהול נגישות דיילים</Text>
      </Animated.View>
    </Animated.View>
  );
}

function TrainLoader() {
  const travel = useRef(new Animated.Value(0)).current;
  const bounce = useRef(new Animated.Value(0)).current;
  const puff1 = useRef(new Animated.Value(0)).current;
  const puff2 = useRef(new Animated.Value(0)).current;
  const puff3 = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const travelLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(travel, { toValue: 1, duration: 1900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.timing(travel, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );

    const bounceLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(bounce, { toValue: 1, duration: 220, easing: Easing.linear, useNativeDriver: true }),
        Animated.timing(bounce, { toValue: 0, duration: 220, easing: Easing.linear, useNativeDriver: true }),
      ])
    );

    const puffLoop = (anim, delay) => Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.timing(anim, { toValue: 1, duration: 900, easing: Easing.out(Easing.quad), useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0, duration: 0, useNativeDriver: true }),
      ])
    );

    travelLoop.start();
    bounceLoop.start();
    puffLoop(puff1, 0).start();
    puffLoop(puff2, 300).start();
    puffLoop(puff3, 600).start();

    return () => {
      travelLoop.stop();
      bounceLoop.stop();
    };
  }, []);

  const translateX = travel.interpolate({ inputRange: [0, 1], outputRange: [-85, 85] });
  const translateY = bounce.interpolate({ inputRange: [0, 1], outputRange: [0, -3] });

  const puffStyle = (anim) => ({
    opacity: anim.interpolate({ inputRange: [0, 0.2, 1], outputRange: [0, 0.6, 0] }),
    transform: [
      { translateY: anim.interpolate({ inputRange: [0, 1], outputRange: [0, -22] }) },
      { translateX: anim.interpolate({ inputRange: [0, 1], outputRange: [0, 10] }) },
      { scale: anim.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1.3] }) },
    ],
  });

  return (
    <View style={styles.trainLoaderWrap}>
      <Animated.View style={[styles.trainLoaderPuff, puffStyle(puff1)]} />
      <Animated.View style={[styles.trainLoaderPuff, puffStyle(puff2)]} />
      <Animated.View style={[styles.trainLoaderPuff, puffStyle(puff3)]} />

      <Animated.View style={[styles.trainLoaderIconWrap, { transform: [{ translateX }, { translateY }] }]}>
        <FontAwesome5 name="train" size={38} color="#0a5c9e" />
      </Animated.View>

      <View style={styles.trainLoaderTrack} />
    </View>
  );
}

/* =========================================================
   TRAIN VISUALIZER
========================================================= */

function TrainVisualizer({ totalCars, location, theme }) {
  const count = Math.min(Math.max(parseInt(totalCars, 10) || 6, 3), 12);
  const cars = Array.from({ length: count }, (_, index) => index + 1);
  let targetIndex = Math.floor(count / 2);
  if (location === 'דרומי') targetIndex = count - 1;

  return (
    <View style={styles.trainViz}>
      <Text style={[styles.trainVizTitle, { color: theme.muted }]}>המחשת קרונות הרכבת</Text>

      <View style={styles.trainTrack}>
        <View style={[styles.trainCar, styles.locomotiveCar]}>
          <FontAwesome5 name="train" size={13} color={theme.muted} />
        </View>
        {cars.map((number, index) => {
          const accessible = index === targetIndex;
          return (
            <View key={number} style={[styles.trainCar, accessible && styles.trainCarActive]}>
              <FontAwesome5 name="subway" size={12} color={accessible ? '#fff' : theme.muted} />
              <Text style={[styles.trainCarText, accessible && styles.trainCarTextActive]}>{number}</Text>
              {accessible && (
                <View style={styles.accessibilityBadgeOnCar}>
                  <Ionicons name="accessibility" size={9} color="#fff" />
                </View>
              )}
            </View>
          );
        })}
      </View>

      <View style={styles.trainDirectionRow}>
        <Text style={styles.trainDirectionText}>צפון ◄</Text>
        <Text style={styles.trainDirectionText}>► דרום</Text>
      </View>
    </View>
  );
}

/* =========================================================
   SMALL PARTS
========================================================= */

function Info({ label, value, theme }) {
  return (
    <Text style={[styles.actionDetailItem, { color: theme.body }]}>
      <B c={theme.text}>{label}:</B> {value || '—'}
    </Text>
  );
}

function Row({ icon, theme, text, children }) {
  return (
    <View style={styles.detailRow}>
      <Ionicons name={icon} size={15} color={theme.muted} style={{ marginLeft: 6 }} />
      <Text style={[styles.detail, { color: theme.body }]}>{text}</Text>
      {children}
    </View>
  );
}

function B({ children, c }) {
  return <Text style={{ fontWeight: '700', color: c }}>{children}</Text>;
}

function Empty({ theme, text }) {
  return (
    <View style={styles.empty}>
      <Ionicons name="checkmark-done-circle-outline" size={52} color="#28a745" />
      <Text style={[styles.emptyText, { color: theme.muted }]}>{text}</Text>
    </View>
  );
}

/* =========================================================
   NEW APPOINTMENT
========================================================= */

function NewAppointmentScreen({ app, update, theme, openStation, openTime, openPlatform, openCars, onSave, saving, onCall }) {
  return (
    <View>
      <View style={styles.formTitleRow}>
        <Text style={[styles.sectionTitle, { color: theme.text, marginBottom: 0 }]}>הזנת תיאום חדש</Text>
        <TouchableOpacity style={styles.dispatchBtn} onPress={onCall} accessibilityRole="button" accessibilityLabel="חיוג למוקד">
          <Ionicons name="call" size={15} color="#28a745" />
          <Text style={styles.dispatchText}>חיוג למוקד</Text>
        </TouchableOpacity>
      </View>

      <View style={[styles.formCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <CheckRow checked={app.isUnscheduled} onPress={() => update({ isUnscheduled: !app.isUnscheduled })} color="#ff4d4d" text="הגעה ללא תיאום מראש" />

        {app.isUnscheduled && (
          <Section theme={theme} title="פרטי נוסע">
            <Field theme={theme} label="שם מלא" value={app.passengerName} onChangeText={(v) => update({ passengerName: v })} placeholder="שם הנוסע" />
            <Field theme={theme} label="טלפון" value={app.passengerPhone} onChangeText={(v) => update({ passengerPhone: v })} placeholder="0500000000" keyboardType="phone-pad" />
          </Section>
        )}

        <Label theme={theme}>תחנת מוצא</Label>
        <Select theme={theme} value={app.fromStation} onPress={() => openStation('from')} />

        <Label theme={theme}>תחנת יעד</Label>
        <Select theme={theme} value={app.toStation} placeholder="בחר תחנת יעד..." onPress={() => openStation('to')} />

        <Label theme={theme}>סוג פעולה</Label>
        <Options values={BOARD_TYPES} value={app.boardType} onChange={(v) => update({ boardType: v })} theme={theme} />

        {app.boardType !== 'להעלות' && (
          <TrainFormSection theme={theme} app={app} update={update} openTime={openTime} openPlatform={openPlatform} openCars={openCars} openStation={openStation} prefix="board" title={app.boardType === 'להוריד ולהעלות' ? 'פרטי רכבת להורדה' : 'פרטי רכבת'} />
        )}

        {app.boardType === 'להוריד ולהעלות' && (
          <TrainFormSection theme={theme} app={app} update={update} openTime={openTime} openPlatform={openPlatform} openCars={openCars} openStation={openStation} prefix="secondary" title="פרטי רכבת להעלאה / החלפה" />
        )}

        {app.boardType === 'להעלות' && (
          <TrainFormSection theme={theme} app={app} update={update} openTime={openTime} openPlatform={openPlatform} openCars={openCars} openStation={openStation} prefix="board" title="פרטי רכבת להעלאה" />
        )}

        <Label theme={theme}>סוג מוגבלות</Label>
        <Options values={DISABILITY_TYPES} value={app.disabilityType} onChange={(v) => update({ disabilityType: v })} theme={theme} />

        <Label theme={theme}>סוג עזרה נדרשת</Label>
        <Options values={HELP_TYPES} value={app.helpType} onChange={(v) => update({ helpType: v })} theme={theme} />

        <Field theme={theme} label="הערת שטח" value={app.stewardNotes} onChangeText={(v) => update({ stewardNotes: v })} placeholder="למשל: ממתין ליד המעלית הראשית" />

        <TouchableOpacity style={[styles.saveBtn, saving && styles.saveBtnDisabled]} disabled={saving} onPress={onSave} accessibilityRole="button" accessibilityLabel="שמור תיאום">
          <Ionicons name="save-outline" size={18} color="#fff" />
          <Text style={styles.doneText}>{saving ? 'שומר...' : 'שמור תיאום'}</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

/* =========================================================
   TRAIN FORM SECTION (shared by new + edit)
========================================================= */

function TrainFormSection({ theme, app, update, openTime, openPlatform, openCars, openStation, prefix, title }) {
  const secondary = prefix === 'secondary';
  const trainKey = secondary ? 'secondaryTrainNum' : 'boardTrainNum';
  const carsKey = secondary ? 'secondaryCarsNum' : 'boardCarsNum';
  const platformKey = secondary ? 'secondaryPlatform' : 'boardPlatform';
  const timeKey = secondary ? 'secondaryTime' : 'boardTime';
  const dateKey = secondary ? 'secondaryDate' : 'boardDate';
  const locationKey = secondary ? 'secondaryCarLocation' : 'boardCarLocation';
  const showTransferOption = !secondary && app.boardType === 'להעלות';

  return (
    <Section theme={theme} title={title} accent>
      <Label theme={theme}>מיקום קרון נכים</Label>
      <Options values={CAR_LOCATIONS} value={app[locationKey]} onChange={(v) => update({ [locationKey]: v })} theme={theme} />

      <View style={styles.three}>
        <View style={styles.third}>
          <Label theme={theme}>מס׳ רכבת</Label>
          <TextInput
            keyboardType="numeric"
            value={app[trainKey]}
            onChangeText={(v) => update({ [trainKey]: v.replace(/\D/g, '') })}
            placeholder="—"
            placeholderTextColor="#8a949d"
            style={[styles.field, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]}
            accessibilityLabel="מספר רכבת"
          />
        </View>
        <View style={styles.third}>
          <Label theme={theme}>קרונות</Label>
          <CarsButton theme={theme} value={app[carsKey]} onPress={() => openCars(carsKey)} />
        </View>
        <View style={styles.third}>
          <Label theme={theme}>רציף</Label>
          <PlatformButton theme={theme} value={app[platformKey]} onPress={() => openPlatform(platformKey)} />
        </View>
      </View>

      <Label theme={theme}>תאריך ושעה מדויקים</Label>
      <TimeButton theme={theme} value={app[timeKey]} dateValue={app[dateKey]} onPress={() => openTime(timeKey)} />

      {showTransferOption && (
        <View style={{ marginTop: 12 }}>
          <CheckRow checked={app.transferEnabled} onPress={() => update({ transferEnabled: !app.transferEnabled })} color="#f56600" text="החלפת רכבת" />

          {app.transferEnabled && (
            <View style={{ marginTop: 4 }}>
              <Label theme={theme}>תחנת מוצא להחלפה</Label>
              <Select theme={theme} value={app.transferFromStation} placeholder="בחר תחנת מוצא..." onPress={() => openStation('transferFrom')} />

              <Label theme={theme}>תחנת יעד להחלפה</Label>
              <Select theme={theme} value={app.transferToStation} placeholder="בחר תחנת יעד..." onPress={() => openStation('transferTo')} />
            </View>
          )}
        </View>
      )}
    </Section>
  );
}

/* =========================================================
   EDIT MODAL
========================================================= */

function EditAppointmentModal({ visible, app, update, theme, onClose, onSave, openStation, openTime, openPlatform, openCars }) {
  /* Rendered as an absolute-positioned overlay (not RN <Modal>) so that the station/time/platform/cars
     pickers, which are opened from within this screen, can stack visually on top of it. Two native
     <Modal> components shown at once behave unreliably (the second can be non-interactive), which is
     what previously made the origin/destination station, platform and date/time fields impossible to edit. */
  if (!visible) return null;
  return (
    <View style={[styles.fullOverlay, { zIndex: 300, elevation: 30, backgroundColor: theme.bg }]}>
      <SafeAreaView style={[styles.modalPage, { backgroundColor: theme.bg }]}>
        <ModalHeader title="עריכת תיאום פעיל" theme={theme} onClose={onClose} />

        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 50 }} keyboardShouldPersistTaps="handled">
          <CheckRow checked={app.isUnscheduled} onPress={() => update({ isUnscheduled: !app.isUnscheduled })} color="#ff4d4d" text="הגעה ללא תיאום מראש" />

          {app.isUnscheduled && (
            <Section theme={theme} title="פרטי נוסע">
              <Field theme={theme} label="שם מלא" value={app.passengerName} onChangeText={(v) => update({ passengerName: v })} placeholder="שם הנוסע" />
              <Field theme={theme} label="טלפון" value={app.passengerPhone} onChangeText={(v) => update({ passengerPhone: v })} placeholder="0500000000" keyboardType="phone-pad" />
            </Section>
          )}

          <Label theme={theme}>תחנת מוצא</Label>
          <Select theme={theme} value={app.fromStation} onPress={() => openStation('from')} />

          <Label theme={theme}>תחנת יעד</Label>
          <Select theme={theme} value={app.toStation} placeholder="בחר תחנת יעד..." onPress={() => openStation('to')} />

          <Label theme={theme}>סוג פעולה</Label>
          <Options values={BOARD_TYPES} value={app.boardType} onChange={(v) => update({ boardType: v })} theme={theme} />

          {app.boardType !== 'להעלות' && (
            <TrainFormSection theme={theme} app={app} update={update} openTime={openTime} openPlatform={openPlatform} openCars={openCars} openStation={openStation} prefix="board" title={app.boardType === 'להוריד ולהעלות' ? 'פרטי רכבת להורדה' : 'פרטי רכבת'} />
          )}

          {app.boardType === 'להוריד ולהעלות' && (
            <TrainFormSection theme={theme} app={app} update={update} openTime={openTime} openPlatform={openPlatform} openCars={openCars} openStation={openStation} prefix="secondary" title="פרטי רכבת להעלאה / החלפה" />
          )}

          {app.boardType === 'להעלות' && (
            <TrainFormSection theme={theme} app={app} update={update} openTime={openTime} openPlatform={openPlatform} openCars={openCars} openStation={openStation} prefix="board" title="פרטי רכבת להעלאה" />
          )}

          <Label theme={theme}>סוג מוגבלות</Label>
          <Options values={DISABILITY_TYPES} value={app.disabilityType} onChange={(v) => update({ disabilityType: v })} theme={theme} />

          <Label theme={theme}>סוג עזרה נדרשת</Label>
          <Options values={HELP_TYPES} value={app.helpType} onChange={(v) => update({ helpType: v })} theme={theme} />

          <Field theme={theme} label="הערת שטח" value={app.stewardNotes} onChangeText={(v) => update({ stewardNotes: v })} placeholder="הערה לדייל" />

          <TouchableOpacity style={styles.saveBtn} onPress={onSave} accessibilityRole="button" accessibilityLabel="שמור שינויים">
            <Ionicons name="checkmark" size={20} color="#fff" />
            <Text style={styles.doneText}>שמור שינויים</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

/* =========================================================
   HISTORY
========================================================= */

function HistoryCard({ item, theme }) {
  return (
    <View style={[styles.history, { backgroundColor: theme.card, borderColor: theme.border }]}>
      <View style={styles.cardTop}>
        <View style={styles.badgeOrange}>
          <Ionicons name="calendar-outline" size={14} color="#f56600" />
          <Text style={styles.orangeText}>{formatDateShort(item.boardDate)}  •  {item.boardTime}</Text>
        </View>
        <Text style={styles.closed}>בוצע ✓</Text>
      </View>

      <Text style={[styles.historyRoute, { color: theme.text }]}>{item.fromStation} → {item.toStation}</Text>
      <Text style={[styles.detail, { color: theme.body }]}><B c={theme.text}>נוסע:</B> {item.passengerName}</Text>
      <Text style={[styles.detail, { color: theme.body }]}><B c={theme.text}>רכבת:</B> {item.boardTrainNum}</Text>
      <Text style={styles.closedBy}>בוצע על ידי: {item.closedBy || '—'}</Text>
      {item.closedAt ? <Text style={styles.closedBy}>זמן ביצוע: {formatDate(item.closedAt)}</Text> : null}
    </View>
  );
}

/* =========================================================
   FORM PARTS
========================================================= */

function Label({ theme, children }) {
  return <Text style={[styles.label, { color: theme.body }]}>{children}</Text>;
}

function Field({ theme, label, value, onChangeText, placeholder, ...props }) {
  return (
    <>
      {label ? <Label theme={theme}>{label}</Label> : null}
      <TextInput
        {...props}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor="#8a949d"
        style={[styles.field, { backgroundColor: theme.input, borderColor: theme.border, color: theme.text }]}
        accessibilityLabel={label || placeholder}
      />
    </>
  );
}

function Select({ theme, value, placeholder = 'בחר תחנה...', onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.select, { backgroundColor: theme.input, borderColor: theme.border }]} accessibilityRole="button" accessibilityLabel={value || placeholder}>
      <Ionicons name="chevron-down" size={18} color={theme.muted} />
      <Text style={[styles.selectText, { color: value ? theme.text : '#8a949d' }]}>{value || placeholder}</Text>
    </TouchableOpacity>
  );
}

function TimeButton({ theme, value, dateValue, onPress }) {
  const dateLabel = formatDateShort(dateValue);
  const display = value ? (dateLabel ? `${dateLabel}  •  ${value}` : value) : 'בחר תאריך ושעה';
  return (
    <TouchableOpacity onPress={onPress} style={[styles.timeButton, { backgroundColor: theme.input, borderColor: theme.border }]} accessibilityRole="button" accessibilityLabel={value ? `נבחר ${display}` : 'בחר תאריך ושעה'}>
      <Ionicons name="calendar-outline" size={18} color="#0a5c9e" />
      <Text style={{ color: '#0a5c9e', fontWeight: '800' }}>{display}</Text>
    </TouchableOpacity>
  );
}

function PlatformButton({ theme, value, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.timeButton, { backgroundColor: theme.input, borderColor: theme.border }]} accessibilityRole="button" accessibilityLabel={value ? `רציף נבחר ${value}` : 'בחר רציף'}>
      <Ionicons name="git-branch-outline" size={18} color="#0a5c9e" />
      <Text style={{ color: '#0a5c9e', fontWeight: '800' }}>{value ? `רציף ${value}` : 'בחר רציף'}</Text>
    </TouchableOpacity>
  );
}

function CarsButton({ theme, value, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={[styles.timeButton, { backgroundColor: theme.input, borderColor: theme.border }]} accessibilityRole="button" accessibilityLabel={value ? `מספר קרונות נבחר ${value}` : 'בחר מספר קרונות'}>
      <FontAwesome5 name="train" size={15} color="#0a5c9e" />
      <Text style={{ color: '#0a5c9e', fontWeight: '800' }}>{value || '6'}</Text>
    </TouchableOpacity>
  );
}

function Options({ values, value, onChange, theme }) {
  return (
    <View style={styles.options}>
      {values.map((item) => {
        const selected = item === value;
        return (
          <TouchableOpacity
            key={item}
            onPress={() => onChange(item)}
            style={[styles.option, { backgroundColor: theme.sub, borderColor: theme.border }, selected && styles.optionSelected]}
            accessibilityRole="button"
            accessibilityState={{ selected }}
            accessibilityLabel={item}
          >
            <Text style={[styles.optionText, { color: selected ? '#fff' : theme.body }]}>{item}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

function CheckRow({ checked, onPress, color, text }) {
  return (
    <TouchableOpacity onPress={onPress} style={styles.checkRow} accessibilityRole="checkbox" accessibilityState={{ checked }} accessibilityLabel={text}>
      <Ionicons name={checked ? 'checkbox' : 'square-outline'} size={23} color={color} />
      <Text style={[styles.checkText, { color }]}>{text}</Text>
    </TouchableOpacity>
  );
}

function Section({ theme, title, children, accent = false }) {
  return (
    <View style={[styles.sectionBox, { backgroundColor: theme.sub, borderColor: accent ? '#f56600' : theme.border }]}>
      <Text style={[styles.sectionSub, { color: accent ? '#f56600' : theme.text }]}>{title}</Text>
      {children}
    </View>
  );
}

function ModalHeader({ title, theme, onClose }) {
  return (
    <View style={[styles.modalHeader, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
      <TouchableOpacity onPress={onClose} accessibilityRole="button" accessibilityLabel="סגור">
        <Ionicons name="close" size={27} color={theme.text} />
      </TouchableOpacity>
      <Text style={[styles.modalTitle, { color: theme.text }]}>{title}</Text>
      <View style={{ width: 27 }} />
    </View>
  );
}

/* =========================================================
   STATION MODAL
========================================================= */

const STATION_MODAL_TITLES = {
  from: 'בחר תחנת מוצא',
  to: 'בחר תחנת יעד',
  transferFrom: 'בחר תחנת מוצא להחלפה',
  transferTo: 'בחר תחנת יעד להחלפה',
};

function StationModal({ visible, field, theme, search, setSearch, stations, onSelect, onClose }) {
  /* Overlay (not native <Modal>) so it can reliably stack above EditAppointmentModal — see note there. */
  if (!visible) return null;
  return (
    <View style={[styles.fullOverlay, { zIndex: 400, elevation: 40, backgroundColor: theme.bg }]}>
      <SafeAreaView style={[styles.modalPage, { backgroundColor: theme.bg }]}>
        <ModalHeader title={STATION_MODAL_TITLES[field] || 'בחר תחנה'} theme={theme} onClose={onClose} />

        <View style={{ padding: 12 }}>
          <Input icon="search" theme={theme} value={search} onChangeText={setSearch} placeholder="חפש תחנה..." autoFocus />
        </View>

        <FlatList
          data={stations}
          keyExtractor={(item) => item}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={[styles.stationRow, { backgroundColor: theme.card, borderBottomColor: theme.border }]}
              onPress={() => onSelect(item)}
              accessibilityRole="button"
              accessibilityLabel={`בחר תחנת ${item}`}
            >
              <Ionicons name="train-outline" size={19} color="#0a5c9e" />
              <Text style={[styles.stationText, { color: theme.text }]}>{item}</Text>
            </TouchableOpacity>
          )}
          ListEmptyComponent={<Empty theme={theme} text="לא נמצאו תחנות." />}
        />
      </SafeAreaView>
    </View>
  );
}

/* =========================================================
   TIME MODAL
========================================================= */

const DATE_OPTION_COUNT = 30;

const buildDateOptions = () => {
  const options = [];
  const now = new Date();
  for (let i = 0; i < DATE_OPTION_COUNT; i += 1) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() + i);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const iso = `${y}-${m}-${day}`;
    const weekday = d.toLocaleDateString('he-IL', { weekday: 'short' });
    options.push({ iso, label: `${weekday} ${day}/${m}` });
  }
  return options;
};

function TimePickerModal({ visible, initialValue, initialDate, onClose, onSave }) {
  const [hour, setHour] = useState('14');
  const [minute, setMinute] = useState('30');
  const [date, setDate] = useState(todayISODate());

  const dateOptions = useMemo(() => buildDateOptions(), [visible]);
  const dateLabels = useMemo(() => dateOptions.map((d) => d.label), [dateOptions]);

  useEffect(() => {
    if (!visible) return;
    if (isValidTime(initialValue)) {
      const [h, m] = initialValue.split(':');
      setHour(h);
      setMinute(m);
    } else {
      setHour('14');
      setMinute('30');
    }
    const matched = isValidDate(initialDate) ? dateOptions.find((d) => d.iso === initialDate) : null;
    setDate(matched ? matched.label : dateOptions[0]?.label);
  }, [visible, initialValue, initialDate]);

  const hours = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, '0'));
  const minutes = Array.from({ length: 60 }, (_, i) => String(i).padStart(2, '0'));

  const handleSave = () => {
    const chosen = dateOptions.find((d) => d.label === date) || dateOptions[0];
    onSave(hour, minute, chosen?.iso);
  };

  if (!visible) return null;
  return (
    <View style={[styles.overlay, styles.fullOverlay, { zIndex: 500, elevation: 50 }]}>
      <View style={styles.timeCardContainer}>
        <Text style={styles.timeModalMainTitle}>בחירת תאריך ושעה</Text>

          <View style={[styles.timePickerContainer, { height: 184 }]}>
            <View style={styles.selectedHighlightBar} />
            <TimeColumn values={dateLabels} selected={date} onSelect={setDate} wide />
            <TimeColumn values={hours} selected={hour} onSelect={setHour} />
            <Text style={styles.timeColonText}>:</Text>
            <TimeColumn values={minutes} selected={minute} onSelect={setMinute} />
          </View>

          <TouchableOpacity style={styles.confirmTimeFullBtn} onPress={handleSave} accessibilityRole="button" accessibilityLabel="אישור תאריך ושעה">
            <Text style={styles.primaryText}>אישור</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.cancelTimeTextBtn} onPress={onClose} accessibilityRole="button" accessibilityLabel="ביטול">
            <Text style={styles.cancelTimeText}>ביטול</Text>
          </TouchableOpacity>
      </View>
    </View>
  );
}

function TimeColumn({ values, selected, onSelect, wide }) {
  const index = values.indexOf(selected);
  const ref = useRef(null);

  useEffect(() => {
    if (index < 0) return;
    const timer = setTimeout(() => {
      ref.current?.scrollTo({ y: index * 46, animated: false });
    }, 50);
    return () => clearTimeout(timer);
  }, [index]);

  return (
    <View style={[styles.timeColWrapper, wide && { width: 92 }]}>
      <FlatList
        ref={ref}
        data={values}
        keyExtractor={(item) => item}
        showsVerticalScrollIndicator={false}
        snapToInterval={46}
        decelerationRate="fast"
        contentContainerStyle={{ paddingVertical: 69 }}
        onMomentumScrollEnd={(event) => {
          const y = event.nativeEvent.contentOffset.y;
          const nextIndex = Math.round(y / 46);
          if (values[nextIndex]) onSelect(values[nextIndex]);
        }}
        renderItem={({ item }) => {
          const selectedItem = item === selected;
          return (
            <View style={styles.timePickerItem}>
              <Text style={[wide ? styles.timePickerTextSmall : styles.timePickerText, selectedItem ? styles.timeSelectedText : styles.timeUnselectedText]}>{item}</Text>
            </View>
          );
        }}
      />
    </View>
  );
}

/* Generic 1-column scroll picker, reused for platform (רציף) selection */
function PlatformPickerModal({ visible, initialValue, onClose, onSave }) {
  const [value, setValue] = useState('1');

  useEffect(() => {
    if (!visible) return;
    setValue(PLATFORM_NUMBERS.includes(initialValue) ? initialValue : '1');
  }, [visible, initialValue]);

  if (!visible) return null;
  return (
    <View style={[styles.overlay, styles.fullOverlay, { zIndex: 500, elevation: 50 }]}>
      <View style={[styles.timeCardContainer, { paddingVertical: 22 }]}>
        <Text style={styles.timeModalMainTitle}>בחירת רציף</Text>

        <View style={[styles.timePickerContainer, { justifyContent: 'center' }]}>
          <View style={styles.selectedHighlightBar} />
          <TimeColumn values={PLATFORM_NUMBERS} selected={value} onSelect={setValue} />
        </View>

        <TouchableOpacity style={styles.confirmTimeFullBtn} onPress={() => onSave(value)} accessibilityRole="button" accessibilityLabel="אישור רציף">
          <Text style={styles.primaryText}>אישור</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.cancelTimeTextBtn} onPress={onClose} accessibilityRole="button" accessibilityLabel="ביטול">
          <Text style={styles.cancelTimeText}>ביטול</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

/* Generic 1-column scroll picker, reused for number-of-cars (מספר קרונות) selection, scrolling 5–14 */
function CarsPickerModal({ visible, initialValue, onClose, onSave }) {
  const [value, setValue] = useState('6');

  useEffect(() => {
    if (!visible) return;
    setValue(CARS_NUMBERS.includes(initialValue) ? initialValue : '6');
  }, [visible, initialValue]);

  if (!visible) return null;
  return (
    <View style={[styles.overlay, styles.fullOverlay, { zIndex: 500, elevation: 50 }]}>
      <View style={[styles.timeCardContainer, { paddingVertical: 22 }]}>
        <Text style={styles.timeModalMainTitle}>בחירת מספר קרונות</Text>

        <View style={[styles.timePickerContainer, { justifyContent: 'center' }]}>
          <View style={styles.selectedHighlightBar} />
          <TimeColumn values={CARS_NUMBERS} selected={value} onSelect={setValue} />
        </View>

        <TouchableOpacity style={styles.confirmTimeFullBtn} onPress={() => onSave(value)} accessibilityRole="button" accessibilityLabel="אישור מספר קרונות">
          <Text style={styles.primaryText}>אישור</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.cancelTimeTextBtn} onPress={onClose} accessibilityRole="button" accessibilityLabel="ביטול">
          <Text style={styles.cancelTimeText}>ביטול</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

/* =========================================================
   SYSTEM ALERT
========================================================= */

function SystemAlertModal({ visible, message, onClose }) {
  if (!visible) return null;
  return (
    <View style={[styles.overlay, styles.fullOverlay, { zIndex: 600, elevation: 60 }]}>
      <View style={[styles.timeCardContainer, { borderWidth: 2, borderColor: '#d9534f' }]}>
        <View style={styles.alertIconCircle}>
          <Ionicons name="warning" size={31} color="#fff" />
        </View>

        <Text style={[styles.timeModalMainTitle, { color: '#d9534f', fontSize: 21 }]}>התרעת מערכת</Text>
        <Text style={styles.alertModalSubtitle}>קיימת הודעה פעילה מהמנהל לגבי נגישות התחנה.</Text>

        <View style={styles.alertBoxHighlight}>
          <Text style={styles.alertBoxHighlightText}>{message || 'אין התראה פעילה.'}</Text>
        </View>

        <TouchableOpacity style={[styles.confirmTimeFullBtn, { backgroundColor: '#0a5c9e' }]} onPress={onClose} accessibilityRole="button" accessibilityLabel="הבנתי, המשך בעבודה">
          <Text style={styles.primaryText}>הבנתי, המשך בעבודה</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

function SettingsModal({
  visible, onClose, theme, settings, updateSettings, closedCount, activeCount, onReport, onCall,
  isAdmin, stewardsList, addSteward, removeSteward, stationsList, addStation, removeStation, changePassword,
  resetStewardPassword, activityLog, clearActivityLog, activeAlertMessage, setActiveAlertMessage, onReset, onLogout, onClearCache,
}) {
  const [name, setName] = useState('');
  const [user, setUser] = useState('');
  const [pass, setPass] = useState('');
  const [newStation, setNewStation] = useState('');
  const [stationFilter, setStationFilter] = useState('');
  const [oldPass, setOldPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [resetUser, setResetUser] = useState('');
  const [resetNewPass, setResetNewPass] = useState('');

  const submitSteward = () => {
    const success = addSteward({ name, user, pass });
    if (success) {
      setName('');
      setUser('');
      setPass('');
    }
  };

  const submitStation = () => {
    const success = addStation(newStation);
    if (success) setNewStation('');
  };

  const submitPasswordChange = () => {
    const success = changePassword({ oldPass, newPass, confirmPass });
    if (success) {
      setOldPass('');
      setNewPass('');
      setConfirmPass('');
    }
  };

  const visibleStations = stationFilter.trim()
    ? stationsList.filter((s) => s.includes(stationFilter.trim()))
    : stationsList;

  const submitResetPassword = () => {
    const success = resetStewardPassword({ user: resetUser, newPass: resetNewPass });
    if (success) {
      setResetUser('');
      setResetNewPass('');
    }
  };

  if (!visible) return null;
  return (
    <View style={[styles.fullOverlay, { zIndex: 200, elevation: 20, backgroundColor: theme.bg }]}>
      <SafeAreaView style={[styles.modalPage, { backgroundColor: theme.bg }]}>
        <ModalHeader title="הגדרות מערכת" theme={theme} onClose={onClose} />

        <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
          <Section theme={theme} title="העדפות דייל">
            <Field theme={theme} label="תחנת אם מועדפת" value={settings.defaultHomeStation} onChangeText={(v) => updateSettings({ defaultHomeStation: v })} placeholder="תחנה" />
            <Toggle theme={theme} label="התראות PUSH" value={settings.pushAlerts} onChange={(v) => updateSettings({ pushAlerts: v })} />
            <Toggle theme={theme} label="צלילי חיווי" value={settings.soundAlerts} onChange={(v) => updateSettings({ soundAlerts: v })} />
            <Toggle theme={theme} label="מצב כהה אוטומטי" value={settings.autoDarkMode} onChange={(v) => updateSettings({ autoDarkMode: v })} />
            <Text style={[styles.settingHint, { color: theme.muted }]}>ההתראות והצלילים נשמרים כהעדפות מקומיות. התראות Push אמיתיות ידרשו חיבור לשרת.</Text>
          </Section>

          <Section theme={theme} title="🔑 שינוי סיסמה אישית">
            <Field theme={theme} label="סיסמה נוכחית" value={oldPass} onChangeText={setOldPass} placeholder="הזן סיסמה נוכחית" secureTextEntry />
            <Field theme={theme} label="סיסמה חדשה" value={newPass} onChangeText={setNewPass} placeholder="6+ תווים, אות וספרה" secureTextEntry />
            <Field theme={theme} label="אימות סיסמה חדשה" value={confirmPass} onChangeText={setConfirmPass} placeholder="הזן שוב את הסיסמה החדשה" secureTextEntry />

            <TouchableOpacity style={styles.saveBtn} onPress={submitPasswordChange} accessibilityRole="button" accessibilityLabel="עדכן סיסמה">
              <Ionicons name="key-outline" size={18} color="#fff" />
              <Text style={styles.doneText}>עדכן סיסמה</Text>
            </TouchableOpacity>
          </Section>

          {isAdmin && (
            <Section theme={theme} title="🚨 התראת מערכת למשתמשים">
              <Text style={[styles.detail, { color: theme.body, marginBottom: 10 }]}>בחר הודעה שתוצג לדיילים:</Text>

              {ALERT_OPTIONS.map((option) => {
                const selected = option === 'תקין (ללא התראה)' ? !activeAlertMessage : activeAlertMessage === option;
                return (
                  <TouchableOpacity
                    key={option}
                    style={[styles.alertOptionSelectRow, { backgroundColor: selected ? '#fde8e8' : theme.input, borderColor: selected ? '#d9534f' : theme.border }]}
                    onPress={() => setActiveAlertMessage(option === 'תקין (ללא התראה)' ? '' : option)}
                    accessibilityRole="radio"
                    accessibilityState={{ selected }}
                    accessibilityLabel={option}
                  >
                    <Ionicons name={selected ? 'radio-button-on' : 'radio-button-off'} size={20} color={selected ? '#d9534f' : theme.muted} />
                    <Text style={[styles.alertOptionText, { color: selected ? '#d9534f' : theme.text, fontWeight: selected ? '800' : '600' }]}>{option}</Text>
                  </TouchableOpacity>
                );
              })}
            </Section>
          )}

          {isAdmin && (
            <Section theme={theme} title="🔐 ניהול דיילים">
              {stewardsList.map((steward) => (
                <View key={steward.username} style={[styles.stewardRowItem, { backgroundColor: theme.input, borderColor: theme.border }]}>
                  <View style={{ flex: 1 }}>
                    <Text style={[styles.stewardNameText, { color: theme.text }]}>{steward.name}{steward.isAdmin ? ' 👑' : ''}</Text>
                    <Text style={[styles.stewardUserText, { color: theme.muted }]}>עובד: {steward.username}</Text>
                  </View>

                  {!steward.isAdmin && (
                    <TouchableOpacity onPress={() => removeSteward(steward.username)} style={styles.removeStewardBtn} accessibilityRole="button" accessibilityLabel={`הסר את ${steward.name}`}>
                      <Ionicons name="trash-outline" size={19} color="#d9534f" />
                    </TouchableOpacity>
                  )}
                </View>
              ))}

              <Text style={[styles.sectionSub, { color: theme.text, marginTop: 15 }]}>הוספת דייל חדש</Text>

              <Field theme={theme} label="שם הדייל" value={name} onChangeText={setName} placeholder="לדוגמה: דייל נתניה" />
              <Field theme={theme} label="מספר עובד" value={user} onChangeText={setUser} placeholder="לדוגמה: 5050" keyboardType="numeric" />
              <Field theme={theme} label="סיסמה" value={pass} onChangeText={setPass} placeholder="סיסמה ראשונית" secureTextEntry />

              <TouchableOpacity style={styles.saveBtn} onPress={submitSteward} accessibilityRole="button" accessibilityLabel="הוסף דייל">
                <Text style={styles.doneText}>הוסף דייל</Text>
              </TouchableOpacity>
            </Section>
          )}

          {isAdmin && (
            <Section theme={theme} title="🔄 איפוס סיסמה לדייל קיים">
              <Text style={[styles.detail, { color: theme.body, marginBottom: 8 }]}>שכחת סיסמה של דייל (כולל מנהל)? אפס אותה כאן לפי מספר עובד.</Text>
              <Field theme={theme} label="מספר עובד" value={resetUser} onChangeText={setResetUser} placeholder="לדוגמה: 10203040" keyboardType="numeric" />
              <Field theme={theme} label="סיסמה חדשה" value={resetNewPass} onChangeText={setResetNewPass} placeholder="6+ תווים, אות וספרה" secureTextEntry />

              <TouchableOpacity style={styles.saveBtn} onPress={submitResetPassword} accessibilityRole="button" accessibilityLabel="אפס סיסמה לדייל">
                <Ionicons name="key-outline" size={18} color="#fff" />
                <Text style={styles.doneText}>אפס סיסמה</Text>
              </TouchableOpacity>
            </Section>
          )}

          {isAdmin && (
            <Section theme={theme} title="🚉 ניהול תחנות">
              <Text style={[styles.detail, { color: theme.body, marginBottom: 8 }]}>{stationsList.length} תחנות ברשימה</Text>

              <Input icon="search" theme={theme} value={stationFilter} onChangeText={setStationFilter} placeholder="חפש תחנה לסינון הרשימה..." accessibilityLabel="חיפוש תחנה לניהול" />

              <View style={styles.stationChipsWrap}>
                {visibleStations.map((station) => (
                  <View key={station} style={[styles.stationChip, { backgroundColor: theme.input, borderColor: theme.border }]}>
                    <Text style={[styles.stationChipText, { color: theme.text }]}>{station}</Text>
                    <TouchableOpacity onPress={() => removeStation(station)} accessibilityRole="button" accessibilityLabel={`הסר את תחנת ${station}`}>
                      <Ionicons name="close-circle" size={17} color="#d9534f" />
                    </TouchableOpacity>
                  </View>
                ))}
              </View>

              <Text style={[styles.sectionSub, { color: theme.text, marginTop: 15 }]}>הוספת תחנה חדשה</Text>
              <Field theme={theme} value={newStation} onChangeText={setNewStation} placeholder="שם התחנה" />

              <TouchableOpacity style={styles.saveBtn} onPress={submitStation} accessibilityRole="button" accessibilityLabel="הוסף תחנה">
                <Text style={styles.doneText}>הוסף תחנה</Text>
              </TouchableOpacity>
            </Section>
          )}

          {isAdmin && (
            <Section theme={theme} title="📜 יומן פעילות">
              <Text style={[styles.detail, { color: theme.body, marginBottom: 8 }]}>{activityLog.length} רשומות (מוצגות 30 האחרונות)</Text>

              {activityLog.length === 0 ? (
                <Text style={[styles.detail, { color: theme.muted }]}>אין עדיין רשומות ביומן.</Text>
              ) : (
                activityLog.slice(0, 30).map((entry) => (
                  <View key={entry.id} style={[styles.logRow, { borderColor: theme.border }]}>
                    <Text style={[styles.logAction, { color: theme.text }]}>{entry.action}</Text>
                    <Text style={[styles.logDetails, { color: theme.body }]}>{entry.details}</Text>
                    <Text style={[styles.logTime, { color: theme.muted }]}>{formatDate(entry.timestamp)}</Text>
                  </View>
                ))
              )}

              {activityLog.length > 0 && (
                <TouchableOpacity style={styles.resetBtn} onPress={clearActivityLog} accessibilityRole="button" accessibilityLabel="נקה יומן פעילות">
                  <Ionicons name="trash-outline" size={17} color="#d9534f" />
                  <Text style={styles.resetText}>נקה יומן</Text>
                </TouchableOpacity>
              )}
            </Section>
          )}

          {isAdmin && (
            <Section theme={theme} title="🧹 ניקוי מטמון">
              <Text style={[styles.detail, { color: theme.body, marginBottom: 8 }]}>
                ניקוי נתונים זמניים שנצברו באפליקציה (יומן פעילות, חיפושים שמורים וכדומה). התיאומים, המשתמשים וההגדרות לא יימחקו.
              </Text>
              <TouchableOpacity style={styles.resetBtn} onPress={onClearCache} accessibilityRole="button" accessibilityLabel="ניקוי מטמון">
                <Ionicons name="refresh-outline" size={17} color="#d9534f" />
                <Text style={styles.resetText}>ניקוי מטמון</Text>
              </TouchableOpacity>
            </Section>
          )}

          <Section theme={theme} title="אנשי קשר">
            <Label theme={theme}>מוקד תיאום / חירום</Label>
            <TouchableOpacity
              style={[styles.timeButton, { backgroundColor: theme.input, borderColor: theme.border }]}
              onPress={() => onCall(settings.emergencyPhone)}
              accessibilityRole="button"
              accessibilityLabel="חייג למוקד חירום"
            >
              <Ionicons name="call" size={17} color="#007AFF" />
              <Text style={{ color: theme.text, fontWeight: '800' }}>{settings.emergencyPhone}</Text>
            </TouchableOpacity>

            <Field theme={theme} label="WhatsApp מנהל משמרת" value={settings.managerPhone} onChangeText={(v) => updateSettings({ managerPhone: v })} keyboardType="phone-pad" placeholder="0500000000" />
          </Section>

          <Section theme={theme} title="📋 דוח משמרת">
            <Text style={[styles.detail, { color: theme.body }]}>תיאומים שבוצעו: {closedCount}</Text>
            <Text style={[styles.detail, { color: theme.body }]}>תיאומים פעילים: {activeCount}</Text>

            <TouchableOpacity style={[styles.saveBtn, { backgroundColor: '#25D366' }]} onPress={onReport} accessibilityRole="button" accessibilityLabel="שלח דוח בוואטסאפ">
              <Text style={styles.doneText}>שלח דוח ב-WhatsApp</Text>
            </TouchableOpacity>
          </Section>

          <TouchableOpacity style={styles.resetBtn} onPress={onReset} accessibilityRole="button" accessibilityLabel="איפוס נתונים מקומיים">
            <Ionicons name="trash-outline" size={17} color="#d9534f" />
            <Text style={styles.resetText}>איפוס נתונים מקומיים</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.logoutBtn} onPress={onLogout} accessibilityRole="button" accessibilityLabel="יציאה מהמערכת">
            <Text style={styles.logoutText}>יציאה מהמערכת</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    </View>
  );
}

function Toggle({ theme, label, value, onChange }) {
  return (
    <View style={styles.toggle}>
      <Text style={[styles.setting, { color: theme.text }]}>{label}</Text>
      <Switch value={value} onValueChange={onChange} trackColor={{ false: '#777', true: '#f56600' }} accessibilityLabel={label} />
    </View>
  );
}

/* =========================================================
   STYLES
========================================================= */

const shadow = { shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: 0.1, shadowRadius: 8 };

const styles = StyleSheet.create({
  loading: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#f2f5f8' },
  splashContainer: { flex: 1, backgroundColor: '#002b4d', alignItems: 'center', justifyContent: 'center', gap: 18 },
  splashLogoBadge: { width: 96, height: 96, borderRadius: 48, backgroundColor: '#0a5c9e', alignItems: 'center', justifyContent: 'center', position: 'relative', borderWidth: 2, borderColor: 'rgba(255,255,255,0.25)' },
  splashAccessBadge: { position: 'absolute', bottom: -6, left: -6, width: 38, height: 38, borderRadius: 19, backgroundColor: '#28a745', alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: '#002b4d' },
  splashTitle: { color: '#fff', fontSize: 26, fontWeight: '900', textAlign: 'center', letterSpacing: 0.3 },
  splashSubtitle: { color: '#aab7c1', fontSize: 14, fontWeight: '700', textAlign: 'center', marginTop: 4 },
  loadingTitle: { marginTop: 12, fontSize: 20, fontWeight: '800', color: '#07345c' },
  loadingText: { marginTop: 6, color: '#66727d' },

  trainLoaderWrap: { width: 200, height: 70, alignItems: 'center', justifyContent: 'flex-end', position: 'relative' },
  trainLoaderTrack: { width: '100%', height: 3, backgroundColor: '#c7d6e2', borderRadius: 2 },
  trainLoaderIconWrap: { position: 'absolute', bottom: 3, alignItems: 'center', justifyContent: 'center' },
  trainLoaderPuff: { position: 'absolute', bottom: 22, width: 10, height: 10, borderRadius: 5, backgroundColor: '#9fb3c4' },

  container: { flex: 1 },

  loginBg: { flex: 1, justifyContent: 'center', padding: 15 },
  loginWrap: { width: '100%', alignSelf: 'center', maxWidth: 480 },
  loginCard: { backgroundColor: '#fff', borderRadius: 22, padding: 22, ...shadow },

  darkBtn: { alignSelf: 'flex-start', width: 38, height: 38, borderRadius: 19, backgroundColor: '#eef2f7', alignItems: 'center', justifyContent: 'center', marginBottom: 10 },

  brand: { flexDirection: 'row', alignItems: 'center', padding: 14, borderRadius: 14, marginBottom: 20 },
  logo: { width: 50, height: 50, borderRadius: 25, backgroundColor: '#003366', alignItems: 'center', justifyContent: 'center', marginLeft: 12, position: 'relative' },
  logoAccessBadge: { position: 'absolute', bottom: -3, left: -3, width: 22, height: 22, borderRadius: 11, backgroundColor: '#28a745', alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#eef3f8' },
  brandTitle: { fontSize: 22, fontWeight: '900', textAlign: 'right', letterSpacing: 0.2 },
  brandSub: { fontSize: 12, textAlign: 'right', marginTop: 2 },

  label: { fontSize: 13, fontWeight: '700', marginTop: 10, marginBottom: 5, textAlign: 'right' },

  inputWrap: { minHeight: 48, borderWidth: 1, borderRadius: 10, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12 },
  input: { flex: 1, fontSize: 15, textAlign: 'right', paddingHorizontal: 8, minHeight: 46 },

  primary: { minHeight: 50, backgroundColor: '#f56600', borderRadius: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 18 },
  primaryText: { color: '#fff', fontSize: 15, fontWeight: '800' },

  loginDisclaimer: { textAlign: 'center', marginTop: 14, fontSize: 11 },

  header: { backgroundColor: '#003b66', paddingHorizontal: 16, paddingTop: Platform.OS === 'android' ? 35 : 13, paddingBottom: 14, borderBottomLeftRadius: 16, borderBottomRightRadius: 16 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  titleRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  headerLogoBadge: { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.16)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.35)', alignItems: 'center', justifyContent: 'center', position: 'relative' },
  headerLogoAccessBadge: { position: 'absolute', bottom: -4, left: -4, width: 17, height: 17, borderRadius: 9, backgroundColor: '#28a745', alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: '#003b66' },
  headerTitle: { color: '#fff', fontSize: 17, fontWeight: '900', letterSpacing: 0.3 },
  offlineBanner: { flexDirection: 'row', alignItems: 'center', gap: 7, backgroundColor: '#fff8d9', borderBottomWidth: 1, borderBottomColor: '#ffe18a', paddingVertical: 8, paddingHorizontal: 14 },
  offlineBannerText: { flex: 1, color: '#7d6416', fontSize: 11.5, fontWeight: '700', textAlign: 'right' },
  headerActions: { flexDirection: 'row', gap: 8 },
  circleBtn: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,.14)', alignItems: 'center', justifyContent: 'center' },
  user: { color: '#ffd34d', fontWeight: '700', fontSize: 12, textAlign: 'right', marginTop: 6 },

  tabs: { flexDirection: 'row', backgroundColor: '#002b4d', marginHorizontal: 16, marginTop: 10, borderRadius: 12, padding: 5 },
  tab: { flex: 1, paddingVertical: 9, alignItems: 'center', borderRadius: 9 },
  tabActive: { backgroundColor: '#07578c' },
  tabText: { color: '#c8d0d7', fontWeight: '600', fontSize: 12 },
  tabTextActive: { color: '#fff', fontWeight: '800' },

  content: { paddingHorizontal: 16, paddingTop: 16 },
  contentTop: { paddingHorizontal: 16, paddingTop: 16, paddingBottom: 4 },
  titleWithScheduleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  scheduleBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 9, paddingVertical: 7, borderRadius: 8, borderWidth: 1, borderColor: '#0a5c9e', backgroundColor: '#edf5fb' },
  scheduleBtnText: { color: '#0a5c9e', fontWeight: '800', fontSize: 12 },
  scheduleErrorBox: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30 },
  scheduleLoadingBox: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  scheduleErrorText: { fontSize: 14, fontWeight: '700', textAlign: 'center', marginTop: 10 },
  sectionTitle: { fontSize: 18, fontWeight: '800', textAlign: 'right', marginBottom: 12 },

  card: { borderRadius: 16, padding: 16, marginBottom: 14, borderRightWidth: 6, elevation: 4, ...shadow },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 9 },
  cardTopLeft: { flexDirection: 'row', gap: 6, alignItems: 'center' },

  badgeOrange: { flexDirection: 'row', gap: 5, alignItems: 'center', backgroundColor: '#fff2e6', paddingHorizontal: 8, paddingVertical: 5, borderRadius: 7 },
  orangeText: { color: '#f56600', fontWeight: '800', fontSize: 13 },
  badgeRed: { flexDirection: 'row', gap: 4, alignItems: 'center', backgroundColor: '#ff4d4d', paddingHorizontal: 8, paddingVertical: 5, borderRadius: 7 },
  redText: { color: '#fff', fontWeight: '800', fontSize: 12 },

  editCircle: { width: 34, height: 34, borderRadius: 17, backgroundColor: '#0a5c9e', alignItems: 'center', justifyContent: 'center' },

  actionBadge: { alignSelf: 'flex-start', paddingHorizontal: 9, paddingVertical: 5, borderRadius: 7, marginBottom: 9 },
  actionBadgeText: { fontSize: 12, fontWeight: '800' },

  route: { borderRadius: 10, padding: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  routeStation: { flex: 1, alignItems: 'center' },
  routeLabel: { fontSize: 10, color: '#7c8790', fontWeight: '700' },
  routeName: { fontSize: 13, fontWeight: '800', textAlign: 'center', marginTop: 2 },

  details: { padding: 11, borderRadius: 10, marginBottom: 8 },
  detailRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 7 },
  detail: { fontSize: 12.5, textAlign: 'right', flex: 1 },

  quick: { flexDirection: 'row', gap: 7, marginRight: 7 },
  whatsapp: { backgroundColor: '#25D366', width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  call: { backgroundColor: '#007AFF', width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },

  redStrong: { color: '#d9534f', fontWeight: '800' },
  blueStrong: { color: '#0a5c9e', fontWeight: '800' },

  actionSectionBox: { borderRadius: 10, padding: 11, marginBottom: 10, borderWidth: 1 },
  actionSectionTitle: { fontSize: 13.5, fontWeight: '800', textAlign: 'right', marginBottom: 7 },
  actionDetailsGrid: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8, flexWrap: 'wrap', gap: 4 },
  actionDetailItem: { fontSize: 12, textAlign: 'right' },

  transferAlertBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#fde8e8', padding: 7, borderRadius: 7, marginBottom: 8 },
  transferAlertText: { color: '#a94442', fontSize: 11.5, fontWeight: '700', flex: 1, textAlign: 'right' },

  trainViz: { marginTop: 6, padding: 8, backgroundColor: 'rgba(0,0,0,0.03)', borderRadius: 8 },
  trainVizTitle: { fontSize: 10.5, fontWeight: '700', textAlign: 'right', marginBottom: 4 },
  trainTrack: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 3, marginVertical: 4, flexWrap: 'wrap' },
  trainCar: { width: 27, height: 32, backgroundColor: '#e2e8f0', borderRadius: 5, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  locomotiveCar: { backgroundColor: '#94a3b8', width: 31, borderRadius: 7, borderWidth: 1, borderColor: '#64748b' },
  trainCarActive: { backgroundColor: '#0a5c9e' },
  trainCarText: { fontSize: 9, fontWeight: '800', color: '#475569', marginTop: 1 },
  trainCarTextActive: { color: '#fff' },
  accessibilityBadgeOnCar: { position: 'absolute', top: -4, right: -4, backgroundColor: '#28a745', width: 13, height: 13, borderRadius: 7, alignItems: 'center', justifyContent: 'center' },
  trainDirectionRow: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 4, marginTop: 2 },
  trainDirectionText: { fontSize: 9, color: '#94a3b8', fontWeight: '700' },

  note: { marginTop: 5, padding: 9, borderRadius: 7, backgroundColor: '#fff8d9', borderWidth: 1, borderColor: '#ffe18a' },
  noteText: { fontSize: 12, color: '#7d6416', textAlign: 'right' },
  metaText: { fontSize: 10, textAlign: 'right', marginTop: 5 },

  doneBtn: { minHeight: 50, borderRadius: 12, backgroundColor: '#28a745', flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', marginTop: 14 },
  doneText: { color: '#fff', fontWeight: '800', fontSize: 14 },

  empty: { alignItems: 'center', justifyContent: 'center', paddingTop: 50, paddingHorizontal: 25 },
  emptyText: { marginTop: 10, textAlign: 'center', fontSize: 14, fontWeight: '600' },

  formTitleRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  dispatchBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 9, paddingVertical: 7, borderRadius: 8, borderWidth: 1, borderColor: '#28a745', backgroundColor: '#e9f8ee' },
  dispatchText: { color: '#28a745', fontWeight: '800', fontSize: 12 },

  formCard: { borderRadius: 16, borderWidth: 1, padding: 16, ...shadow },

  checkRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 7 },
  checkText: { fontSize: 13, fontWeight: '800', marginRight: 8, textAlign: 'right' },

  sectionBox: { borderWidth: 1, borderRadius: 10, padding: 11, marginTop: 12, marginBottom: 4 },
  sectionSub: { fontSize: 14, fontWeight: '800', textAlign: 'right', marginBottom: 4 },

  field: { minHeight: 46, borderWidth: 1, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 9, textAlign: 'right', fontSize: 14 },
  select: { minHeight: 46, borderWidth: 1, borderRadius: 10, paddingHorizontal: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  selectText: { fontSize: 14, flex: 1, textAlign: 'right', marginRight: 8 },

  options: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  option: { paddingHorizontal: 11, paddingVertical: 8, borderRadius: 8, borderWidth: 1 },
  optionSelected: { backgroundColor: '#f56600', borderColor: '#f56600' },
  optionText: { fontSize: 12, fontWeight: '700' },

  three: { flexDirection: 'row', gap: 7 },
  third: { flex: 1 },

  timeButton: { minHeight: 46, borderWidth: 1, borderRadius: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7 },

  saveBtn: { minHeight: 48, borderRadius: 10, backgroundColor: '#003b66', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8, marginTop: 18 },
  saveBtnDisabled: { opacity: 0.55 },

  history: { borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 12, ...shadow },
  historyRoute: { fontWeight: '800', fontSize: 15, textAlign: 'right', marginBottom: 7 },
  closed: { color: '#28a745', fontWeight: '800' },
  closedBy: { fontSize: 11, color: '#78838c', textAlign: 'right', marginTop: 7 },

  toast: { position: 'absolute', left: 16, right: 16, bottom: 18, backgroundColor: '#20252a', borderRadius: 11, padding: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', elevation: 10, ...shadow, shadowOpacity: 0.25 },
  toastText: { color: '#fff', fontWeight: '800' },
  toastSubText: { color: '#b8c2ca', fontSize: 10, marginTop: 3 },
  undo: { backgroundColor: '#f56600', paddingHorizontal: 13, paddingVertical: 8, borderRadius: 7, marginLeft: 10 },
  undoText: { color: '#fff', fontWeight: '800' },

  modalPage: { flex: 1 },
  fullOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 },
  modalHeader: { height: 62, borderBottomWidth: 1, paddingHorizontal: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  modalTitle: { fontSize: 18, fontWeight: '800' },

  stationRow: { paddingVertical: 15, paddingHorizontal: 16, borderBottomWidth: 1, flexDirection: 'row', alignItems: 'center', gap: 12 },
  stationText: { fontSize: 16, fontWeight: '700', textAlign: 'right', flex: 1 },

  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,.75)', alignItems: 'center', justifyContent: 'center' },
  timeCardContainer: { width: '88%', maxWidth: 350, backgroundColor: '#fff', borderRadius: 22, padding: 22, alignItems: 'center', ...shadow, shadowOpacity: 0.3 },
  timeModalMainTitle: { fontSize: 24, fontWeight: '800', color: '#07345c', marginBottom: 10, textAlign: 'center' },

  timePickerContainer: { height: 184, width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', position: 'relative', marginVertical: 10 },
  selectedHighlightBar: { position: 'absolute', top: 69, height: 46, left: 10, right: 10, backgroundColor: '#f2f6fb', borderRadius: 8, borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#0a5c9e' },
  timeColWrapper: { height: 184, width: 65 },
  timePickerItem: { height: 46, alignItems: 'center', justifyContent: 'center' },
  timePickerText: { fontSize: 22, fontWeight: '800' },
  timePickerTextSmall: { fontSize: 15, fontWeight: '800' },
  timeSelectedText: { color: '#07345c' },
  timeUnselectedText: { color: '#b0c0d0' },
  timeColonText: { fontSize: 28, fontWeight: '800', color: '#07345c', marginHorizontal: 6 },

  confirmTimeFullBtn: { width: '100%', minHeight: 48, borderRadius: 11, backgroundColor: '#f56600', alignItems: 'center', justifyContent: 'center', marginTop: 12 },
  cancelTimeTextBtn: { marginTop: 12, padding: 6 },
  cancelTimeText: { color: '#66727d', fontSize: 14, fontWeight: '700' },

  toggle: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingVertical: 7 },
  setting: { fontSize: 14, fontWeight: '700' },
  settingHint: { fontSize: 10.5, lineHeight: 16, textAlign: 'right', marginTop: 6 },

  logoutBtn: { height: 48, borderRadius: 10, borderWidth: 1, borderColor: '#d9534f', alignItems: 'center', justifyContent: 'center', marginTop: 16 },
  logoutText: { color: '#d9534f', fontWeight: '800' },

  resetBtn: { minHeight: 46, borderRadius: 10, borderWidth: 1, borderColor: '#d9534f', alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 8, marginTop: 18 },
  resetText: { color: '#d9534f', fontWeight: '800' },

  stewardRowItem: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 10, borderRadius: 8, borderWidth: 1, marginBottom: 6 },
  stewardNameText: { fontSize: 13.5, fontWeight: '800', textAlign: 'right' },
  stewardUserText: { fontSize: 11.5, textAlign: 'right', marginTop: 2 },
  removeStewardBtn: { padding: 7 },

  stationChipsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 10 },
  stationChip: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 9, paddingVertical: 6, borderRadius: 7, borderWidth: 1 },
  stationChipText: { fontSize: 12, fontWeight: '700' },

  logRow: { borderBottomWidth: 1, paddingVertical: 8 },
  logAction: { fontSize: 13, fontWeight: '800', textAlign: 'right' },
  logDetails: { fontSize: 11.5, textAlign: 'right', marginTop: 2 },
  logTime: { fontSize: 10, textAlign: 'right', marginTop: 2 },

  alertOptionSelectRow: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 12, borderRadius: 8, borderWidth: 1, marginBottom: 6 },
  alertOptionText: { fontSize: 13, textAlign: 'right', flex: 1 },

  alertIconCircle: { width: 54, height: 54, borderRadius: 27, backgroundColor: '#d9534f', alignItems: 'center', justifyContent: 'center', marginBottom: 5 },
  alertModalSubtitle: { fontSize: 13, textAlign: 'center', color: '#34404a', marginBottom: 12 },
  alertBoxHighlight: { backgroundColor: '#fde8e8', borderWidth: 1, borderColor: '#f5c6cb', padding: 10, borderRadius: 8, width: '100%', alignItems: 'center', marginBottom: 5 },
  alertBoxHighlightText: { color: '#721c24', fontWeight: '800', fontSize: 13.5, textAlign: 'center' },
});
